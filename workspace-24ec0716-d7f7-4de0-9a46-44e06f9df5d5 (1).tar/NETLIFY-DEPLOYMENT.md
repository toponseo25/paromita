# Netlify Deployment Guide

## Applied Physiology & Nutrition Portal

This guide will help you deploy your Next.js application to Netlify.

---

## 📋 Prerequisites

- Netlify account (free tier works fine)
- Git repository (GitHub, GitLab, or Bitbucket)
- Project code ready

---

## 🚀 Deployment Methods

### Method 1: Git-based Deployment (Recommended)

This is the easiest and most automated method.

#### Step 1: Push to Git Repository

```bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Ready for Netlify deployment"

# Add remote (replace with your repo URL)
git remote add origin https://github.com/your-username/your-repo.git

# Push to main branch
git push -u origin main
```

#### Step 2: Connect to Netlify

1. Go to [app.netlify.com](https://app.netlify.com)
2. Sign in or create an account
3. Click "Add new site" → "Import an existing project"
4. Select your Git provider (GitHub, GitLab, or Bitbucket)
5. Authorize Netlify to access your repositories
6. Select your repository from the list

#### Step 3: Configure Build Settings

Netlify will auto-detect Next.js, but verify these settings:

**Build Settings:**
- **Branch to deploy:** `main`
- **Build command:** `bun run build`
- **Publish directory:** `.next`

**Environment Variables:**
If needed, add any environment variables:
- `NODE_VERSION`: `18`
- Any API keys or secrets (not needed for this project)

#### Step 4: Deploy

Click "Deploy site" and wait for the build to complete. Netlify will:
1. Install dependencies (using bun)
2. Build the Next.js application
3. Deploy to their global CDN
4. Provide a HTTPS URL (e.g., `your-site.netlify.app`)

---

### Method 2: Manual Deployment via Netlify CLI

#### Step 1: Install Netlify CLI

```bash
# Using npm
npm install -g netlify-cli

# Using bun
bun install -g netlify-cli
```

#### Step 2: Login to Netlify

```bash
netlify login
```

This will open a browser window for authentication.

#### Step 3: Initialize Netlify

```bash
netlify init
```

Follow the prompts:
- Choose "Create & configure a new site"
- Select your team
- Give your site a name

#### Step 4: Deploy

```bash
# Production deployment
netlify deploy --prod
```

Netlify will build and deploy your site.

---

### Method 3: Drag & Drop (Quickest, No Git)

⚠️ **Note:** This method doesn't work well with API routes. Use Method 1 or 2 for this project.

---

## ⚙️ Configuration Files

### `netlify.toml`

This file is already created in your project root with the following configuration:

```toml
[build]
  command = "bun run build"
  publish = ".next"

[build.environment]
  NODE_VERSION = "18"
  BUN_VERSION = "latest"

[[plugins]]
  package = "@netlify/plugin-nextjs"

[dev]
  command = "bun run dev"
  port = 3000
  publish = ".next"
```

### `package.json` Scripts

Updated for Netlify compatibility:

```json
{
  "scripts": {
    "dev": "next dev -p 3000",
    "build": "next build",
    "start": "next start",
    "lint": "eslint ."
  }
}
```

### `next.config.ts`

Optimized for Netlify deployment:

```typescript
const nextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  trailingSlash: true,
  compress: true,
  poweredByHeader: false,
  images: {
    formats: ['image/avif', 'image/webp'],
  },
};
```

---

## 🌐 Custom Domain (Optional)

### Using Netlify's Free Subdomain

Your site will be deployed to: `https://your-site-name.netlify.app`

### Using Your Own Domain

1. Go to **Domain settings** in Netlify
2. Click "Add custom domain"
3. Enter your domain (e.g., `yourdomain.com`)
4. Update your DNS settings as instructed by Netlify

---

## 🔧 Troubleshooting

### Build Fails

**Issue:** Build command fails

**Solutions:**
1. Check build logs for specific errors
2. Verify Node.js version is set to 18
3. Ensure all dependencies are in `package.json`
4. Run `bun run build` locally first to verify it works

### API Routes Not Working

**Issue:** API routes return 404

**Solutions:**
1. Ensure `@netlify/plugin-nextjs` is in `netlify.toml`
2. API routes are in `src/app/api/` directory
3. No static export configuration in `next.config.ts`

### 404 Errors on Navigation

**Issue:** Clicking links shows 404

**Solutions:**
1. Check `[[redirects]]` in `netlify.toml`
2. Ensure `trailingSlash: true` in `next.config.ts`
3. Verify pages are in correct directory structure

### Images Not Loading

**Issue:** Images show 404 or broken

**Solutions:**
1. Ensure images are in `public/` directory
2. Check image paths in code (no `/public/` prefix needed)
3. Verify image optimization config in `next.config.ts`

---

## 📊 Environment Variables

This project doesn't require any environment variables for basic functionality. However, if you add features that need them:

1. Go to **Site settings** → **Environment variables**
2. Add variables (e.g., `API_KEY`, `DATABASE_URL`)
3. Select the environment (Development, Preview, Production)

**Note:** The database (SQLite) is currently configured for local development only. For production, you may need to:
- Migrate to PostgreSQL or MySQL
- Update `DATABASE_URL` environment variable
- Use Netlify Functions or a separate database service

---

## 🔄 Continuous Deployment

With Git-based deployment (Method 1), Netlify will automatically redeploy when you:

1. Push changes to your connected branch
2. Open a pull request (creates a preview deploy)
3. Merge a pull request (updates production)

### Workflow

```bash
# Make changes to your code
# ...

# Commit and push
git add .
git commit -m "Update content"
git push origin main

# Netlify automatically detects and deploys
```

---

## 📈 Performance Optimization

Your Next.js app is already optimized:

✅ **Automatic Code Splitting** - Next.js splits code automatically
✅ **Image Optimization** - Configured for AVIF and WebP
✅ **Static Generation** - Pages pre-built where possible
✅ **CDN Caching** - Netlify's global CDN
✅ **GZIP Compression** - Enabled in next.config.ts
✅ **Browser Caching** - Configured in netlify.toml headers

---

## 🔒 Security

✅ **HTTPS** - Automatic with Netlify
✅ **Headers** - Security headers configured in netlify.toml
✅ **No Secrets in Code** - Environment variables for sensitive data
✅ **Medical Disclaimer** - Footer includes appropriate disclaimers

---

## 📝 Post-Deployment Checklist

After deployment, verify:

- [ ] Homepage loads correctly
- [ ] All 17 pages are accessible
- [ ] Navigation menu works
- [ ] TDEE Calculator API responds
- [ ] Glossary search works
- [ ] Images display properly
- [ ] Dark mode toggle functions
- [ ] Mobile view is responsive
- [ ] No console errors
- [ ] SEO metadata visible (check page source)
- [ ] Sitemap.xml accessible (`/sitemap.xml`)
- [ ] Robots.txt accessible (`/robots.txt`)

---

## 🎯 Next Steps

After successful deployment:

1. **Test thoroughly** - Navigate through all pages and features
2. **Set up analytics** - Add Google Analytics or similar
3. **Custom domain** - Add your own domain if desired
4. **Monitor** - Use Netlify's dashboard to monitor performance
5. **Scale** - Upgrade plan if you need more bandwidth or features

---

## 💡 Tips

1. **Preview Deploys:** Pull requests generate preview URLs for testing
2. **Rollback:** Netlify keeps deploy history for easy rollbacks
3. **Forms:** Netlify supports form handling out of the box
4. **Functions:** Add serverless functions if needed
5. **Edge Functions:** Deploy Next.js to the edge for better performance

---

## 📞 Support

- **Netlify Docs:** [docs.netlify.com](https://docs.netlify.com)
- **Next.js on Netlify:** [www.netlify.com/platform/nextjs](https://www.netlify.com/platform/nextjs)
- **Community:** [answers.netlify.com](https://answers.netlify.com)

---

## 🎉 Summary

Your Applied Physiology & Nutrition Portal is ready for Netlify deployment!

**Quick Deploy:**
1. Push code to GitHub
2. Connect repository to Netlify
3. Click deploy

**Estimated Time:** 5-10 minutes
**Cost:** Free tier available
**Performance:** Excellent (global CDN, automatic optimization)

Good luck with your deployment! 🚀
