import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Applied Physiology & Nutrition - Decoding Your Biology, Fueling Your Life",
  description: "Evidence-based health education rooted in human physiology. We translate clinical research into actionable strategies for how you eat, move, and live. Explore articles on digestion, metabolism, hormonal health, sports nutrition, and therapeutic nutrition.",
  keywords: [
    "physiology",
    "nutrition",
    "evidence-based health",
    "applied physiology",
    "sports nutrition",
    "metabolism",
    "hormonal health",
    "digestive health",
    "PCOS",
    "diabetes management",
    "circadian rhythms",
    "muscle protein synthesis",
    "cortisol",
    "insulin",
    "TDEE calculator",
    "metabolic health",
    "gut health",
    "chrononutrition",
    "post-prandial somnolence",
    "leucine threshold",
    "mTOR pathway",
    "HPA axis",
    "scientific health education",
  ],
  authors: [{ name: "Paromita" }],
  creator: "Paromita",
  publisher: "Applied Physiology & Nutrition",
  robots: "index, follow",
  alternates: {
    canonical: "https://appliedphysiology.com",
  },
  icons: {
    icon: "/logo.svg",
    shortcut: "/logo.svg",
    apple: "/logo.svg",
  },
  openGraph: {
    title: "Applied Physiology & Nutrition - Decoding Your Biology, Fueling Your Life",
    description: "Evidence-based health education rooted in human physiology. We translate clinical research into actionable strategies for how you eat, move, and live.",
    url: "https://appliedphysiology.com",
    siteName: "Applied Physiology & Nutrition",
    locale: "en_US",
    type: "website",
    images: [
      {
        url: "/images/hero-digestion.jpg",
        width: 1344,
        height: 768,
        alt: "Applied Physiology & Nutrition - Digestive Physiology Education",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Applied Physiology & Nutrition",
    description: "Evidence-based health education rooted in human physiology.",
    creator: "@appliedphysiology",
    images: {
      url: "/images/hero-digestion.jpg",
      alt: "Applied Physiology & Nutrition Portal",
    },
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen flex flex-col`}
      >
        <Navigation />
        <main className="flex-1">{children}</main>
        <Footer />
        <Toaster />
      </body>
    </html>
  );
}
