import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Brain, Activity, Heart, Zap, ArrowRight, BookOpen } from 'lucide-react';
import Link from 'next/link';
import { generateMetadata } from '@/lib/metadata';

export const metadata = generateMetadata({
  title: 'The Fundamentals - Physiology 101',
  description: 'Build a foundation of understanding in human physiology. Learn about digestive mechanics, metabolism, hormonal signaling, and cardiovascular function. Evidence-based educational resources for the curious mind.',
  path: '/fundamentals',
});

export default function FundamentalsPage() {
  const topics = [
    {
      icon: Brain,
      title: 'Digestive Mechanics',
      subtitle: 'From Bite to Biochemistry',
      description: 'Understanding how food travels through your gastrointestinal tract, the role of enzymes, stomach acid, and how nutrients are absorbed at the cellular level.',
      color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400',
      articles: [
        'The Odyssey of an Apple: Tracing the Path from Bite to Biology',
        'Enzymatic Breakdown: How Your Body Processes Food',
      ],
    },
    {
      icon: Activity,
      title: 'Metabolic Processes',
      subtitle: 'Energy Production & Utilization',
      description: 'Learn how your body converts food into energy through glycolysis, the Krebs cycle, and oxidative phosphorylation. Understand basal metabolic rate, resting energy expenditure, and how exercise affects energy balance.',
      color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400',
      articles: [
        'Metabolism Myths Debunked',
        'Understanding Your Resting Metabolic Rate',
      ],
    },
    {
      icon: Zap,
      title: 'Hormonal Signaling',
      subtitle: 'The Chemical Messenger Network',
      description: 'Explore the endocrine system and how hormones like insulin, cortisol, leptin, and ghrelin regulate appetite, stress responses, and metabolic processes. Understand feedback loops and homeostasis.',
      color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/20 dark:text-rose-400',
      articles: [
        'Cortisol and Cravings: The Stress-Food Connection',
        'Insulin Signaling: Beyond Blood Sugar',
      ],
    },
    {
      icon: Heart,
      title: 'Cardiovascular Function',
      subtitle: 'The Heart of Physiology',
      description: 'Understand how your heart works, blood pressure regulation, the role of arteries and veins, and how cardiovascular health impacts overall physiology. Learn about heart rate variability and autonomic regulation.',
      color: 'bg-sky-100 text-sky-700 dark:bg-sky-900/20 dark:text-sky-400',
      articles: [
        'Heart Rate Variability Explained',
        'Understanding Blood Pressure: Beyond the Numbers',
      ],
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-background via-background to-muted/30">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(66,153,225,0.05),transparent_50%)]" />
        <div className="container-custom py-20 md:py-32 relative">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6" variant="secondary">
              <Brain className="w-3 h-3 mr-2" />
              Physiology 101
            </Badge>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
              How Your Body
              <br />
              <span className="gradient-text">Actually Works</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
              Build a foundation of understanding. Before you optimize, you must understand the machinery. Learn the fundamental processes that keep you alive and functioning.
            </p>
          </div>
        </div>
      </section>

      {/* Topics Grid */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              The Four Pillars of Physiology
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Master these foundational concepts and you'll have the framework to understand virtually any health topic.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {topics.map((topic) => (
              <Card key={topic.title} className="h-full transition-all duration-300 hover:shadow-lg hover:border-primary/50 hover:-translate-y-1">
                <CardHeader>
                  <div className={`w-16 h-16 rounded-xl ${topic.color} flex items-center justify-center mb-4`}>
                    <topic.icon className="w-8 h-8" />
                  </div>
                  <CardTitle className="text-2xl mb-2">{topic.title}</CardTitle>
                  <CardDescription className="text-base font-medium">
                    {topic.subtitle}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {topic.description}
                  </p>
                  <div className="border-t pt-4">
                    <h4 className="text-sm font-semibold mb-2 flex items-center">
                      <BookOpen className="w-4 h-4 mr-2" />
                      Related Articles
                    </h4>
                    <ul className="space-y-2">
                      {topic.articles.map((article) => (
                        <li key={article} className="text-sm">
                          <Link href="/articles" className="text-primary hover:underline flex items-center">
                            <ArrowRight className="w-3 h-3 mr-1" />
                            {article}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Learning Path */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-6">
              <Zap className="w-3 h-3 mr-2" />
              Learning Path
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Where to Start?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-primary">1</span>
                  </div>
                  <CardTitle className="text-lg">Beginner</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Start with <strong>Digestive Mechanics</strong> to understand how food becomes nutrients.
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-primary">2</span>
                  </div>
                  <CardTitle className="text-lg">Intermediate</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Move to <strong>Metabolic Processes</strong> and <strong>Hormonal Signaling</strong>.
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-primary">3</span>
                  </div>
                  <CardTitle className="text-lg">Advanced</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Integrate everything with <strong>Cardiovascular Function</strong>.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <Card className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground border-0 overflow-hidden">
            <CardContent className="p-8 md:p-12 text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready to Dive Deeper?
              </h2>
              <p className="text-lg mb-8 max-w-2xl mx-auto opacity-90">
                Explore our articles that break down these complex topics into accessible, evidence-based explanations.
              </p>
              <Button asChild size="lg" variant="secondary" className="text-base px-8">
                <Link href="/articles">
                  <BookOpen className="w-5 h-5 mr-2" />
                  Explore Articles
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
