import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Brain, GraduationCap, Heart, Award, BookOpen, Target, Lightbulb } from 'lucide-react';
import { generateMetadata } from '@/lib/metadata';

export const metadata = generateMetadata({
  title: 'About the Empathetic Scientist',
  description: 'Learn about Applied Physiology & Nutrition. Discover the credentials, philosophy, and mission behind our evidence-based health education portal. Meet the Root Cause Seekers we serve.',
  path: '/about',
});

export default function AboutPage() {
  const credentials = [
    {
      icon: GraduationCap,
      title: 'Advanced Physiology Training',
      description: 'Specialized education in human physiology, with deep understanding of metabolic processes, hormonal pathways, and cellular function.',
    },
    {
      icon: Award,
      title: 'Clinical Experience',
      description: 'Years of hands-on clinical experience working with diverse patients, translating complex physiology into actionable health strategies.',
    },
    {
      icon: Heart,
      title: 'Evidence-Based Practice',
      description: 'Commitment to peer-reviewed research and established science. Every recommendation is backed by citations and references.',
    },
    {
      icon: BookOpen,
      title: 'Research Literacy',
      description: 'Ability to critically evaluate scientific literature and distinguish between correlation, causation, and marketing hype.',
    },
  ];

  const values = [
    {
      icon: Target,
      title: 'Mechanism-First',
      description: 'Every recommendation is rooted in physiological processes. We don\'t say "sugar causes crashes"—we explain the insulin-mediated uptake of glucose and the subsequent counter-regulatory hormone response.',
    },
    {
      icon: Heart,
      title: 'Compassionate Realism',
      description: 'Biology is messy. Stress, circadian misalignment, and socioeconomic factors influence health. The tone is non-judgmental, recognizing that cortisol drives cravings as a survival mechanism, not a moral failing.',
    },
    {
      icon: Lightbulb,
      title: 'Accessible Precision',
      description: 'We use correct terminology (e.g., "post-prandial somnolence") but immediately deconstruct it into understandable concepts, ensuring scientific literacy is elevated rather than bypassed.',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-muted/30">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6" variant="secondary">
              <Brain className="w-3 h-3 mr-2" />
              The Empathetic Scientist
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              About <span className="gradient-text">Applied Physiology & Nutrition</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Bridging the gap between clinical research and daily living
            </p>
          </div>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto">
            <Card className="bg-muted/30 border-primary/20">
              <CardContent className="p-8 md:p-12">
                <div className="prose prose-lg max-w-none">
                  <h2 className="text-2xl md:text-3xl font-bold mb-6">The Mission</h2>
                  <p className="text-muted-foreground text-lg leading-relaxed mb-4">
                    I started Applied Physiology & Nutrition because I saw a gap. In the lab, we talk about "substrate utilization" and "mitochondrial density." In the kitchen, we talk about "calories" and "superfoods." The truth is somewhere in the middle.
                  </p>
                  <p className="text-muted-foreground text-lg leading-relaxed mb-4">
                    With a background in physiology and years of clinical experience, my mission is to act as your translator. I don't just tell you to eat protein; I explain how leucine triggers mTOR to rebuild the muscle you broke down in the gym.
                  </p>
                  <p className="text-muted-foreground text-lg leading-relaxed">
                    I don't just say "reduce stress"; I explain how cortisol competes with insulin to drive abdominal fat storage. Knowledge is the ultimate therapeutic intervention.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Credentials */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Credentials & Expertise
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Building authority through evidence and experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {credentials.map((credential) => (
              <Card key={credential.title} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <credential.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">{credential.title}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {credential.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              The Empathetic Scientist: Three Core Tenets
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              How we communicate matters as much as what we communicate
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {values.map((value) => (
              <Card key={value.title} className="text-center h-full hover:shadow-lg transition-all hover:-translate-y-1">
                <CardContent className="p-8">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                    <value.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-4">{value.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {value.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Target Audience */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Who Is This For?
              </h2>
              <p className="text-muted-foreground">
                The Root Cause Seekers
              </p>
            </div>

            <div className="space-y-6">
              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-3 flex items-center">
                    <Target className="w-5 h-5 mr-2 text-primary" />
                    The Quantified Self Enthusiast
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    You use wearables (Oura, Whoop, Apple Watch) and track your sleep, HRV, and activity. You want to understand the physiology behind those numbers—what does an elevated HRV actually mean? Why does sleep quality fluctuate?
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-3 flex items-center">
                    <Heart className="w-5 h-5 mr-2 text-primary" />
                    The Chronic Warrior
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    You're managing PCOS, diabetes, IBS, or another chronic condition. You're tired of generic advice that doesn't account for your unique physiology. You want to understand the pathophysiology to better advocate for yourself in clinical settings.
                  </p>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-3 flex items-center">
                    <BookOpen className="w-5 h-5 mr-2 text-primary" />
                    The Skeptical Student
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    You're a nutrition or physiology student looking for reliable summaries of complex mechanisms. You want accurate, well-explained breakdowns of topics like the Krebs cycle, muscle protein synthesis, or hormonal signaling pathways.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <Card className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground border-0 overflow-hidden">
            <CardContent className="p-8 md:p-12 text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready to Understand Your Body?
              </h2>
              <p className="text-lg mb-8 max-w-2xl mx-auto opacity-90">
                Stop guessing. Start understanding. Explore our articles, tools, and resources designed to help you decode your biology.
              </p>
              <p className="text-lg font-medium mb-6">
                "Decoding Your Biology, Fueling Your Life."
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
