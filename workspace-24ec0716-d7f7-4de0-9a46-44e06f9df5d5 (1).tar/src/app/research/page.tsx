import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Search, Clock, CheckCircle, XCircle, BookOpen, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { generateMetadata } from '@/lib/metadata';

export const metadata = generateMetadata({
  title: 'Research Radar - 2025 Trends and Studies',
  description: 'Stay current with the latest breakthroughs in chrononutrition, gut health science, and performance research. We analyze trends like circadian eating, prebiotic sodas, and separate evidence from hype.',
  path: '/research',
});

export default function ResearchPage() {
  const trends = [
    {
      title: 'Circadian Eating',
      subtitle: 'When to Eat, Not Just What',
      status: 'emerging',
      description: 'Research suggests aligning food intake with your body\'s natural rhythms may improve metabolic health. Early time-restricted eating (eTRE) shows promise for insulin sensitivity, but individual chronotype matters.',
      evidence: 'Strong',
      year: '2024-2025',
      keyStudies: [
        'Mattson et al. on intermittent fasting (NEJM 2019)',
        'Sutton et al. on eTRE (Cell Metabolism 2018)',
        'Ongoing trials on chronotype-specific protocols',
      ],
      actionItems: [
        'Consider early eating window if possible',
        'Maintain consistent meal times',
        'Align protein intake with activity',
      ],
    },
    {
      title: 'Prebiotic Sodas & Gut Health',
      subtitle: 'Functional Beverages vs Marketing',
      status: 'trending',
      description: 'The explosion of gut-healthy sodas contains both innovation and hype. Some formulations include legitimate prebiotic fibers like inulin and GOS, while others rely on minimal amounts for marketing claims.',
      evidence: 'Mixed',
      year: '2024-2025',
      keyStudies: [
        'Systematic reviews on prebiotic fiber benefits (2023)',
        'Individual variation in microbiome response studies',
        'Comparative analysis of commercial formulations',
      ],
      actionItems: [
        'Check fiber content on labels',
        'Start low, go slow with prebiotic intake',
        'Monitor individual tolerance',
        'Whole foods remain superior to processed alternatives',
      ],
    },
    {
      title: 'Cold Plunge & Hormetic Stress',
      subtitle: 'Beyond the Wim Hof Effect',
      status: 'investigating',
      description: 'Cold exposure protocols are gaining popularity, but the evidence for routine benefits is mixed. While acute stress response is well-documented, long-term adaptation and practical utility require more research.',
      evidence: 'Developing',
      year: '2024-2025',
      keyStudies: [
        'Costello et al. on cold water immersion (PLOS One 2022)',
        'Pole et al. on post-exercise recovery',
        'Comparative studies on stress hormones',
      ],
      actionItems: [
        'May be useful for post-workout recovery',
        'Acute benefits may not equal long-term adaptation',
        'Individual response varies significantly',
      ],
    },
  ];

  const getEvidenceColor = (evidence: string) => {
    switch (evidence) {
      case 'Strong':
        return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400';
      case 'Mixed':
        return 'bg-amber-100 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400';
      case 'Developing':
        return 'bg-sky-100 text-sky-700 dark:bg-sky-900/20 dark:text-sky-400';
      default:
        return 'bg-muted';
    }
  };

  const getEvidenceIcon = (evidence: string) => {
    switch (evidence) {
      case 'Strong':
        return CheckCircle;
      case 'Mixed':
        return Search;
      case 'Developing':
        return Clock;
      default:
        return Search;
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-background via-background to-muted/30">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(66,153,225,0.05),transparent_50%)]" />
        <div className="container-custom py-20 md:py-32 relative">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6" variant="secondary">
              <TrendingUp className="w-3 h-3 mr-2" />
              2025 Updates
            </Badge>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
              Research
              <br />
              <span className="gradient-text">Radar</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
              Separating evidence from hype. We analyze the latest trends in chrononutrition, gut health, and performance research—so you don't have to.
            </p>
          </div>
        </div>
      </section>

      {/* How We Work */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                How We Evaluate Research
              </h2>
              <p className="text-muted-foreground">
                Evidence hierarchy, sample sizes, and replication matter
              </p>
            </div>

            <Card className="bg-muted/30 border-primary/20">
              <CardContent className="p-8 md:p-12">
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-sm font-bold text-primary">1</span>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Systematic Reviews First</h3>
                      <p className="text-sm text-muted-foreground">
                        Meta-analyses and systematic reviews of randomized controlled trials (RCTs) provide the highest quality evidence.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-sm font-bold text-primary">2</span>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Individual Study Quality</h3>
                      <p className="text-sm text-muted-foreground">
                        Sample size, study duration, control groups, and blinding all matter. Rodent studies are informative, but human physiology is different.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-sm font-bold text-primary">3</span>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Individual Variation</h3>
                      <p className="text-sm text-muted-foreground">
                        Average effects don't tell the whole story. Genetics, microbiome composition, and lifestyle factors influence individual response.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Trend Analysis */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              2025 Trend Analysis
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              What's emerging, what's trending, and what needs more research
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8">
            {trends.map((trend) => {
              const EvidenceIcon = getEvidenceIcon(trend.evidence);
              return (
                <Card key={trend.title} className="hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Badge variant="secondary" className="capitalize">
                            {trend.status}
                          </Badge>
                          <Badge className={getEvidenceColor(trend.evidence)}>
                            <EvidenceIcon className="w-3 h-3 mr-1" />
                            {trend.evidence} Evidence
                          </Badge>
                        </div>
                        <CardTitle className="text-2xl mb-1">{trend.title}</CardTitle>
                        <CardDescription className="text-base">
                          {trend.subtitle}
                        </CardDescription>
                      </div>
                      <TrendingUp className="w-8 h-8 text-primary flex-shrink-0" />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <h4 className="font-semibold mb-2 flex items-center">
                        <Search className="w-4 h-4 mr-2" />
                        The Science
                      </h4>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {trend.description}
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Key Studies</h4>
                      <ul className="space-y-1">
                        {trend.keyStudies.map((study, idx) => (
                          <li key={idx} className="text-sm text-muted-foreground flex items-start">
                            <ArrowRight className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                            {study}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="font-semibold mb-3">Action Items</h4>
                      <ul className="space-y-2">
                        {trend.actionItems.map((item, idx) => (
                          <li key={idx} className="text-sm flex items-start">
                            <CheckCircle className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0 text-primary" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Stay Updated */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <Card className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground border-0 overflow-hidden">
            <CardContent className="p-8 md:p-12 text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Stay Current with Research
              </h2>
              <p className="text-lg mb-8 max-w-2xl mx-auto opacity-90">
                The science is always evolving. We regularly update our articles with the latest research findings. Explore our evidence-based content.
              </p>
              <Button asChild size="lg" variant="secondary" className="text-base px-8">
                <Link href="/articles">
                  <BookOpen className="w-5 h-5 mr-2" />
                  Read Evidence-Based Articles
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
