import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, Apple, Droplets, Pill, ArrowRight, BookOpen } from 'lucide-react';
import Link from 'next/link';

export default function NutritionPage() {
  const topics = [
    {
      title: 'Macronutrients',
      subtitle: 'Fueling the Machine',
      description: 'Beyond calories. Explore protein amino acid profiles, carbohydrate kinetics, and the structural role of lipids in cell membranes and hormone production.',
      icon: Apple,
      href: '/nutrition/macronutrients',
      color: 'bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400',
      articleCount: 4,
    },
    {
      title: 'Micronutrients',
      subtitle: 'The Spark Plugs',
      description: 'Vitamins and minerals as co-factors for biochemical reactions. Understand bioavailability, absorption mechanisms, and optimal intake strategies.',
      icon: Pill,
      href: '/nutrition/micronutrients',
      color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400',
      articleCount: 3,
    },
    {
      title: 'Hydration',
      subtitle: 'More Than Just Water',
      description: 'Electrolytes do more than hydrate—they generate action potentials. Learn about sodium, potassium, magnesium, and how they enable nerve and muscle function.',
      icon: Droplets,
      href: '/nutrition/hydration',
      color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400',
      articleCount: 2,
    },
    {
      title: 'Supplements',
      subtitle: 'Evidence-Based Enhancement',
      description: 'Cut through the marketing hype. Learn which supplements have evidence and which are expensive urine, backed by peer-reviewed research.',
      icon: Activity,
      href: '/nutrition/supplements',
      color: 'bg-purple-100 text-purple-700 dark:bg-purple-900/20 dark:text-purple-400',
      articleCount: 5,
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-muted/30">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6" variant="secondary">
              <Apple className="w-3 h-3 mr-2" />
              Nutrition Science
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Fueling the <span className="gradient-text">Machine</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Nutrition isn't about magic foods or forbidden ingredients. It's about understanding how nutrients fuel your body at the cellular level. Learn the science behind what you eat.
            </p>
          </div>
        </div>
      </section>

      {/* Topics Grid */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {topics.map((topic) => (
              <Link key={topic.title} href={topic.href} className="group">
                <Card className="h-full transition-all duration-300 hover:shadow-lg hover:border-primary/50 hover:-translate-y-1">
                  <CardHeader>
                    <div className={`w-14 h-14 rounded-xl ${topic.color} flex items-center justify-center mb-4`}>
                      <topic.icon className="w-7 h-7" />
                    </div>
                    <CardTitle className="group-hover:text-primary transition-colors">
                      {topic.title}
                    </CardTitle>
                    <CardDescription className="text-base font-medium">
                      {topic.subtitle}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                      {topic.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary" className="text-xs">
                        <BookOpen className="w-3 h-3 mr-1" />
                        {topic.articleCount} articles
                      </Badge>
                      <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Key Principles */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">
              Evidence-Based Nutrition Principles
            </h2>
            <div className="space-y-4">
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">Quality Over Quantity</h3>
                  <p className="text-sm text-muted-foreground">
                    Not all calories are equal. The micronutrient density and food matrix matter for absorption and metabolic response.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">Bioavailability Matters</h3>
                  <p className="text-sm text-muted-foreground">
                    Spinach is high in iron but low in absorption due to oxalates. Understanding absorption mechanisms is crucial.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">Context is King</h3>
                  <p className="text-sm text-muted-foreground">
                    Nutrient timing, food combinations, and individual physiology all influence how your body uses nutrients.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
