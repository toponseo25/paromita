'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Calculator, Activity, AlertTriangle } from 'lucide-react';

export default function ResourcesPage() {
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [age, setAge] = useState('');
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [activityLevel, setActivityLevel] = useState('sedentary');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const activityLevels = [
    { value: 'sedentary', label: 'Sedentary', description: 'Little or no exercise' },
    { value: 'lightly_active', label: 'Lightly Active', description: 'Light exercise 1-3 days/week' },
    { value: 'moderately_active', label: 'Moderately Active', description: 'Moderate exercise 3-5 days/week' },
    { value: 'very_active', label: 'Very Active', description: 'Hard exercise 6-7 days/week' },
    { value: 'extra_active', label: 'Extra Active', description: 'Very hard exercise & physical job' },
  ];

  const handleCalculate = async () => {
    if (!age || !weight || !height) {
      alert('Please fill in all fields');
      return;
    }

    setLoading(true);
    setResult(null);

    try {
      const response = await fetch('/api/calculate-tdee', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          gender,
          age,
          weight,
          height,
          activityLevel,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setResult(data.data);
      } else {
        alert(data.error || 'Failed to calculate TDEE');
      }
    } catch (error) {
      alert('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-muted/30">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            <Calculator className="w-12 h-12 mx-auto mb-6 text-primary" />
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              TDEE <span className="gradient-text">Calculator</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Calculate your Total Daily Energy Expenditure using the Mifflin-St Jeor equation. Understand your maintenance calories and macro splits.
            </p>
          </div>
        </div>
      </section>

      {/* Calculator */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Input Form */}
              <Card>
                <CardHeader>
                  <CardTitle>Your Information</CardTitle>
                  <CardDescription>
                    Enter your details to calculate your TDEE
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Gender */}
                  <div>
                    <Label className="text-base font-semibold mb-3 block">Gender</Label>
                    <RadioGroup
                      value={gender}
                      onValueChange={(value) => setGender(value as 'male' | 'female')}
                      className="grid grid-cols-2 gap-4"
                    >
                      <div className="flex items-center space-x-2 border rounded-lg p-4 hover:bg-muted/50 cursor-pointer">
                        <RadioGroupItem value="male" id="male" />
                        <Label htmlFor="male" className="cursor-pointer font-medium">
                          Male
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 border rounded-lg p-4 hover:bg-muted/50 cursor-pointer">
                        <RadioGroupItem value="female" id="female" />
                        <Label htmlFor="female" className="cursor-pointer font-medium">
                          Female
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {/* Age */}
                  <div>
                    <Label htmlFor="age" className="text-base font-semibold mb-2 block">
                      Age (years)
                    </Label>
                    <Input
                      id="age"
                      type="number"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      placeholder="e.g., 30"
                      min="16"
                      max="100"
                      className="text-base"
                    />
                  </div>

                  {/* Weight */}
                  <div>
                    <Label htmlFor="weight" className="text-base font-semibold mb-2 block">
                      Weight (kg)
                    </Label>
                    <Input
                      id="weight"
                      type="number"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      placeholder="e.g., 70"
                      min="30"
                      max="300"
                      step="0.1"
                      className="text-base"
                    />
                  </div>

                  {/* Height */}
                  <div>
                    <Label htmlFor="height" className="text-base font-semibold mb-2 block">
                      Height (cm)
                    </Label>
                    <Input
                      id="height"
                      type="number"
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                      placeholder="e.g., 175"
                      min="100"
                      max="250"
                      className="text-base"
                    />
                  </div>

                  {/* Activity Level */}
                  <div>
                    <Label className="text-base font-semibold mb-3 block">
                      Activity Level
                    </Label>
                    <RadioGroup value={activityLevel} onValueChange={setActivityLevel}>
                      {activityLevels.map((level) => (
                        <div key={level.value} className="mb-2">
                          <div className="flex items-center space-x-2 border rounded-lg p-4 hover:bg-muted/50 cursor-pointer">
                            <RadioGroupItem value={level.value} id={level.value} />
                            <Label
                              htmlFor={level.value}
                              className="cursor-pointer flex-1"
                            >
                              <div className="font-medium">{level.label}</div>
                              <div className="text-xs text-muted-foreground">
                                {level.description}
                              </div>
                            </Label>
                          </div>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>

                  <Button
                    onClick={handleCalculate}
                    disabled={loading}
                    size="lg"
                    className="w-full text-base"
                  >
                    {loading ? 'Calculating...' : 'Calculate TDEE'}
                  </Button>
                </CardContent>
              </Card>

              {/* Results */}
              {result && (
                <Card className="lg:sticky lg:top-24">
                  <CardHeader>
                    <CardTitle>Your Results</CardTitle>
                    <CardDescription>
                      Based on the Mifflin-St Jeor equation
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* TDEE */}
                    <div className="bg-primary/5 border border-primary/20 rounded-lg p-6">
                      <div className="text-sm text-muted-foreground mb-2">
                        Total Daily Energy Expenditure
                      </div>
                      <div className="text-4xl font-bold text-primary">
                        {result.tdee}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        calories/day
                      </div>
                    </div>

                    {/* BMR */}
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium">Basal Metabolic Rate (BMR)</span>
                        <span className="text-lg font-bold">{result.bmr}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Calories your body burns at rest
                      </div>
                    </div>

                    {/* Weight Goals */}
                    <div className="space-y-3">
                      <div className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                        <div>
                          <div className="text-sm font-medium">Weight Loss</div>
                          <div className="text-xs text-muted-foreground">
                            -500 cal deficit
                          </div>
                        </div>
                        <div className="text-lg font-bold text-rose-600">
                          {result.weightLoss}
                        </div>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                        <div>
                          <div className="text-sm font-medium">Weight Gain</div>
                          <div className="text-xs text-muted-foreground">
                            +500 cal surplus
                          </div>
                        </div>
                        <div className="text-lg font-bold text-emerald-600">
                          {result.weightGain}
                        </div>
                      </div>
                    </div>

                    {/* Macros */}
                    <div>
                      <div className="text-sm font-semibold mb-3">
                        Suggested Macro Split (40/30/30)
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                          <div>
                            <div className="text-sm font-medium">Protein</div>
                            <div className="text-xs text-muted-foreground">
                              {result.macros.protein.calories} cal
                            </div>
                          </div>
                          <div className="text-lg font-bold">
                            {result.macros.protein.grams}g
                          </div>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                          <div>
                            <div className="text-sm font-medium">Carbs</div>
                            <div className="text-xs text-muted-foreground">
                              {result.macros.carbs.calories} cal
                            </div>
                          </div>
                          <div className="text-lg font-bold">
                            {result.macros.carbs.grams}g
                          </div>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                          <div>
                            <div className="text-sm font-medium">Fat</div>
                            <div className="text-xs text-muted-foreground">
                              {result.macros.fat.calories} cal
                            </div>
                          </div>
                          <div className="text-lg font-bold">
                            {result.macros.fat.grams}g
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="py-12">
        <div className="container-custom">
          <Card className="border-amber-200 bg-amber-50/50 dark:border-amber-900/50 dark:bg-amber-950/20 max-w-4xl mx-auto">
            <CardContent className="p-6">
              <div className="flex items-start space-x-4">
                <AlertTriangle className="w-5 h-5 text-amber-700 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-amber-900 dark:text-amber-100 mb-2">
                    Important Disclaimer
                  </h3>
                  <p className="text-sm text-amber-800 dark:text-amber-200 leading-relaxed">
                    This calculator provides estimates based on the Mifflin-St Jeor equation. Individual variations in metabolism, muscle mass, and other factors may affect actual caloric needs. Consult with a healthcare professional or registered dietitian before making significant changes to your diet or exercise routine.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
