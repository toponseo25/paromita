'use client';

import { useState, useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, BookOpen } from 'lucide-react';

export default function GlossaryPage() {
  const [searchTerm, setSearchTerm] = useState('');

  const glossaryTerms = [
    {
      term: 'Anabolism',
      category: 'Metabolism',
      definition: 'The metabolic process of building complex molecules from simpler ones. This includes processes like muscle protein synthesis and glycogen synthesis. Anabolism requires energy input.',
    },
    {
      term: 'BMR (Basal Metabolic Rate)',
      category: 'Metabolism',
      definition: 'The number of calories your body needs to maintain basic physiological functions at complete rest, including breathing, circulation, cell production, and nutrient processing. BMR accounts for 60-70% of total daily energy expenditure.',
    },
    {
      term: 'Butyrate',
      category: 'Gut Health',
      definition: 'A short-chain fatty acid (SCFA) produced when gut bacteria ferment dietary fiber. It serves as the primary energy source for colon cells and has anti-inflammatory properties.',
    },
    {
      term: 'Catabolism',
      category: 'Metabolism',
      definition: 'The metabolic process of breaking down complex molecules into simpler ones to release energy. This includes processes like glycolysis and breaking down body fat for fuel.',
    },
    {
      term: 'Cephalic Phase',
      category: 'Digestion',
      definition: 'The first phase of digestion that occurs before food even enters the stomach. The sight, smell, or thought of food triggers salivary and gastric secretions to prepare the body for incoming nutrients.',
    },
    {
      term: 'Chyme',
      category: 'Digestion',
      definition: 'The semi-liquid mixture of partially digested food and gastric juices that passes from the stomach to the small intestine.',
    },
    {
      term: 'Chrononutrition',
      category: 'Nutrition',
      definition: 'The study of how the timing of food intake influences health outcomes, considering interactions with circadian rhythms and biological clocks.',
    },
    {
      term: 'Circadian Rhythm',
      category: 'Physiology',
      definition: 'The body\'s internal 24-hour biological clock that regulates various physiological processes, including hormone secretion, metabolism, and sleep-wake cycles.',
    },
    {
      term: 'Cortisol',
      category: 'Hormones',
      definition: 'The primary stress hormone released by the adrenal glands. It mobilizes glucose for energy, temporarily suppresses insulin, and promotes fat storage, particularly in the abdominal area.',
    },
    {
      term: 'Glycemic Index (GI)',
      category: 'Nutrition',
      definition: 'A numerical scale (0-100) that ranks carbohydrates based on how quickly they raise blood glucose levels after consumption.',
    },
    {
      term: 'Glycemic Load (GL)',
      category: 'Nutrition',
      definition: 'A measure that takes into account both the glycemic index of a food and the amount of carbohydrate in a serving. GL is considered more practical than GI for meal planning.',
    },
    {
      term: 'Glucotoxicity',
      category: 'Metabolism',
      definition: 'Cellular damage caused by chronically elevated blood glucose levels. It can lead to insulin resistance, beta-cell dysfunction, and complications associated with diabetes.',
    },
    {
      term: 'HPA Axis',
      category: 'Physiology',
      definition: 'The hypothalamic-pituitary-adrenal axis, a complex set of interactions among the hypothalamus, pituitary gland, and adrenal glands that controls the body\'s reaction to stress.',
    },
    {
      term: 'Hormesis',
      category: 'Physiology',
      definition: 'The beneficial effect of a mild stressor or toxin. In health, hormetic stressors like exercise or cold exposure can trigger adaptive responses that improve resilience.',
    },
    {
      term: 'Hypertrophy',
      category: 'Exercise',
      definition: 'The increase in muscle size (cross-sectional area) resulting from resistance training. It\'s primarily driven by muscle protein synthesis exceeding muscle protein breakdown.',
    },
    {
      term: 'Insulin Resistance',
      category: 'Metabolism',
      definition: 'A condition where cells don\'t respond effectively to insulin, making it harder for glucose to enter cells. This can lead to elevated blood sugar and is a precursor to type 2 diabetes.',
    },
    {
      term: 'Insulin Sensitivity',
      category: 'Metabolism',
      definition: 'The degree to which cells respond to insulin. Higher insulin sensitivity is generally beneficial, allowing cells to efficiently take up glucose from the bloodstream.',
    },
    {
      term: 'Inositol',
      category: 'Supplements',
      definition: 'A type of sugar that influences insulin signaling. Myo-inositol and D-chiro-inositol supplements are commonly used in PCOS management to improve insulin sensitivity.',
    },
    {
      term: 'Krebs Cycle (Citric Acid Cycle)',
      category: 'Metabolism',
      definition: 'A series of chemical reactions that occur in the mitochondria, converting Acetyl-CoA from food into ATP (energy), carbon dioxide, and water. It\'s central to cellular respiration.',
    },
    {
      term: 'Leucine Threshold',
      category: 'Nutrition',
      definition: 'The minimum amount of leucine (approximately 2.5-3 grams) required in a single meal to maximally stimulate muscle protein synthesis. This typically requires 25-30g of high-quality protein.',
    },
    {
      term: 'mTOR',
      category: 'Physiology',
      definition: 'Mammalian Target of Rapamycin—a protein complex that acts as the master regulator of cell growth. When activated by leucine and mechanical tension, it stimulates muscle protein synthesis.',
    },
    {
      term: 'NEAT (Non-Exercise Activity Thermogenesis)',
      category: 'Metabolism',
      definition: 'Energy expended through daily activities that are not structured exercise, including fidgeting, standing, walking, and doing household chores. NEAT varies significantly between individuals.',
    },
    {
      term: 'Nitric Oxide',
      category: 'Physiology',
      definition: 'A gas molecule that signals blood vessels to relax and dilate (vasodilation), improving blood flow and lowering blood pressure. Nitrate-rich vegetables like beets can boost nitric oxide production.',
    },
    {
      term: 'Orexin',
      category: 'Hormones',
      definition: 'Also called hypocretin, orexin is a neuropeptide produced in the hypothalamus that regulates wakefulness, arousal, and appetite. High glucose levels can inhibit orexin neurons, causing post-meal sleepiness.',
    },
    {
      term: 'Oxidative Stress',
      category: 'Physiology',
      definition: 'An imbalance between free radicals (unstable molecules) and antioxidants in the body. It can damage cells and contribute to aging and various diseases.',
    },
    {
      term: 'Peristalsis',
      category: 'Digestion',
      definition: 'The wave-like muscular contractions that move food through the digestive tract. It\'s controlled by the enteric nervous system and can be disrupted by stress.',
    },
    {
      term: 'Post-Prandial Somnolence',
      category: 'Physiology',
      definition: 'The scientific term for "food coma"—the drowsiness that occurs after eating, particularly after carbohydrate-rich meals. It\'s mediated by insulin, tryptophan, and orexin suppression.',
    },
    {
      term: 'Satiety Hormones',
      category: 'Hormones',
      definition: 'Hormones like leptin, peptide YY, and GLP-1 that signal fullness to the brain, reducing appetite. They work with ghrelin (the hunger hormone) to regulate energy balance.',
    },
    {
      term: 'Substrate Utilization',
      category: 'Metabolism',
      definition: 'The preferential use of different fuel sources (glucose, fatty acids, amino acids) for energy production by the body. This varies based on activity level, dietary intake, and fasting state.',
    },
    {
      term: 'TEF (Thermic Effect of Food)',
      category: 'Metabolism',
      definition: 'The energy required to digest, absorb, and metabolize nutrients. Protein has the highest TEF (20-30%), followed by carbs (5-10%), and fat (0-3%).',
    },
    {
      term: 'TDEE (Total Daily Energy Expenditure)',
      category: 'Metabolism',
      definition: 'The total number of calories you burn in a day, calculated as TDEE = BMR + TEF + NEAT + EAT. It represents your maintenance calorie level.',
    },
    {
      term: 'Vagus Nerve',
      category: 'Physiology',
      definition: 'The tenth cranial nerve that connects the brain to the gut. It regulates digestion and explains why stress signals from the brain can cause digestive issues like diarrhea or constipation.',
    },
    {
      term: 'Villi and Microvilli',
      category: 'Digestion',
      definition: 'Finger-like projections in the small intestine that dramatically increase surface area for nutrient absorption. The combined surface area is roughly equivalent to a tennis court.',
    },
  ];

  const categories = [...new Set(glossaryTerms.map((term) => term.category))];

  const filteredTerms = useMemo(() => {
    if (!searchTerm) return glossaryTerms;

    const searchLower = searchTerm.toLowerCase();
    return glossaryTerms.filter(
      (term) =>
        term.term.toLowerCase().includes(searchLower) ||
        term.definition.toLowerCase().includes(searchLower) ||
        term.category.toLowerCase().includes(searchLower)
    );
  }, [searchTerm, glossaryTerms]);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-muted/30">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            <BookOpen className="w-12 h-12 mx-auto mb-6 text-primary" />
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Physiological <span className="gradient-text">Glossary</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              A searchable database of terms used throughout our articles. Understand the terminology to elevate your scientific literacy.
            </p>
          </div>
        </div>
      </section>

      {/* Search */}
      <section className="py-12">
        <div className="container-custom">
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search for terms (e.g., insulin, cortisol, mTOR)..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 text-base h-12"
              />
            </div>
            <div className="flex flex-wrap gap-2 mt-4">
              <Badge
                variant={searchTerm === '' ? 'default' : 'secondary'}
                className="cursor-pointer"
                onClick={() => setSearchTerm('')}
              >
                All Terms ({glossaryTerms.length})
              </Badge>
              {categories.map((category) => (
                <Badge
                  key={category}
                  variant={searchTerm === category ? 'default' : 'secondary'}
                  className="cursor-pointer"
                  onClick={() => setSearchTerm(category)}
                >
                  {category}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Terms */}
      <section className="pb-16 md:pb-24">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            {filteredTerms.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Search className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-xl font-semibold mb-2">No terms found</h3>
                  <p className="text-muted-foreground">
                    Try searching for a different term
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {filteredTerms.map((item, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-xl font-bold">{item.term}</h3>
                            <Badge variant="secondary" className="text-xs">
                              {item.category}
                            </Badge>
                          </div>
                          <p className="text-muted-foreground leading-relaxed">
                            {item.definition}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Usage Note */}
      <section className="py-12 bg-muted/30">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center">
            <h3 className="text-xl font-semibold mb-4">
              How to Use This Glossary
            </h3>
            <p className="text-muted-foreground leading-relaxed">
              Use this glossary as a reference when reading our articles. If you encounter a term you don\'t understand, search for it here. Understanding these terms will help you grasp the mechanisms behind health recommendations.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
