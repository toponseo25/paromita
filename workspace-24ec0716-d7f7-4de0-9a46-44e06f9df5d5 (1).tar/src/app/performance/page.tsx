import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dumbbell, Clock, Activity, ArrowRight, BookOpen } from 'lucide-react';
import Link from 'next/link';

export default function PerformancePage() {
  const topics = [
    {
      title: 'Sports Nutrition',
      subtitle: 'Fueling for Performance',
      description: 'Energy systems, nutrient timing, and recovery strategies. Learn how to optimize your nutrition for the phosphagen, glycolytic, and oxidative systems.',
      icon: Dumbbell,
      href: '/performance/sports',
      color: 'bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-400',
      articleCount: 4,
    },
    {
      title: 'Circadian Rhythms',
      subtitle: 'Chrononutrition',
      description: 'When you eat matters as much as what you eat. Explore the science of meal timing, peripheral clocks, and aligning nutrition with your biology.',
      icon: Clock,
      href: '/performance/circadian',
      color: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/20 dark:text-indigo-400',
      articleCount: 3,
    },
    {
      title: 'Stress Physiology',
      subtitle: 'The HPA Axis',
      description: 'Understand how stress hormones like cortisol affect metabolism, recovery, and performance. Learn evidence-based stress management strategies.',
      icon: Activity,
      href: '/performance/stress',
      color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/20 dark:text-rose-400',
      articleCount: 4,
    },
  ];

  const featuredArticles = [
    {
      id: 1,
      title: 'Muscle Protein Synthesis Explained: Repair and Rebuild',
      description: 'Understand the mTOR pathway, the leucine threshold, and how your body repairs muscle after exercise.',
      category: 'Sports Nutrition',
      readTime: '10 min',
      href: '/articles/muscle-protein-synthesis-explained',
    },
    {
      id: 2,
      title: 'The Biology of Comfort Food: Why Stress Demands Sugar',
      description: 'Explore the HPA axis, evolutionary mismatch, and the neurochemistry of stress eating.',
      category: 'Stress Physiology',
      readTime: '9 min',
      href: '/articles/cortisol-and-cravings',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-muted/30">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6" variant="secondary">
              <Dumbbell className="w-3 h-3 mr-2" />
              Performance & Life
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Applied Performance <span className="gradient-text">Physiology</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Performance isn't just for athletes—it's about optimizing your physiology for whatever life throws at you. From workouts to sleep cycles, learn how to work with your biology.
            </p>
          </div>
        </div>
      </section>

      {/* Topics Grid */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {topics.map((topic) => (
              <Link key={topic.title} href={topic.href} className="group">
                <Card className="h-full transition-all duration-300 hover:shadow-lg hover:border-primary/50 hover:-translate-y-1">
                  <CardHeader>
                    <div className={`w-14 h-14 rounded-xl ${topic.color} flex items-center justify-center mb-4`}>
                      <topic.icon className="w-7 h-7" />
                    </div>
                    <CardTitle className="group-hover:text-primary transition-colors">
                      {topic.title}
                    </CardTitle>
                    <CardDescription className="text-base font-medium">
                      {topic.subtitle}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                      {topic.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary" className="text-xs">
                        <BookOpen className="w-3 h-3 mr-1" />
                        {topic.articleCount} articles
                      </Badge>
                      <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Articles */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container-custom">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-2">
                Featured Deep Dives
              </h2>
              <p className="text-muted-foreground">
                Evidence-based strategies for performance optimization
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {featuredArticles.map((article) => (
              <Card key={article.id} className="h-full flex flex-col">
                <CardHeader className="flex-1">
                  <div className="flex items-center justify-between mb-4">
                    <Badge variant="secondary" className="text-xs">
                      {article.category}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {article.readTime} read
                    </span>
                  </div>
                  <CardTitle className="text-xl mb-3 hover:text-primary transition-colors">
                    <Link href={article.href}>
                      {article.title}
                    </Link>
                  </CardTitle>
                  <CardDescription className="text-sm leading-relaxed">
                    {article.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
