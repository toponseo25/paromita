import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { gender, age, weight, height, activityLevel } = body;

    // Validate inputs
    if (!gender || !age || !weight || !height || !activityLevel) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const ageNum = parseFloat(age);
    const weightNum = parseFloat(weight); // kg
    const heightNum = parseFloat(height); // cm

    if (
      isNaN(ageNum) ||
      isNaN(weightNum) ||
      isNaN(heightNum) ||
      ageNum < 16 ||
      ageNum > 100 ||
      weightNum < 30 ||
      weightNum > 300 ||
      heightNum < 100 ||
      heightNum > 250
    ) {
      return NextResponse.json(
        { error: 'Invalid input values' },
        { status: 400 }
      );
    }

    // Mifflin-St Jeor Equation
    let bmr: number;

    if (gender === 'male') {
      bmr = 10 * weightNum + 6.25 * heightNum - 5 * ageNum + 5;
    } else {
      bmr = 10 * weightNum + 6.25 * heightNum - 5 * ageNum - 161;
    }

    // Activity multipliers
    const activityMultipliers: Record<string, number> = {
      sedentary: 1.2,
      lightly_active: 1.375,
      moderately_active: 1.55,
      very_active: 1.725,
      extra_active: 1.9,
    };

    const multiplier = activityMultipliers[activityLevel] || 1.2;
    const tdee = Math.round(bmr * multiplier);

    // Calculate macros (standard 40/30/30 split)
    const proteinCalories = Math.round(tdee * 0.3);
    const carbCalories = Math.round(tdee * 0.4);
    const fatCalories = Math.round(tdee * 0.3);

    const proteinGrams = Math.round(proteinCalories / 4);
    const carbGrams = Math.round(carbCalories / 4);
    const fatGrams = Math.round(fatCalories / 9);

    // Weight loss and gain calculations
    const weightLoss = tdee - 500; // 500 calorie deficit
    const weightGain = tdee + 500; // 500 calorie surplus

    return NextResponse.json({
      success: true,
      data: {
        bmr: Math.round(bmr),
        tdee,
        weightLoss,
        weightGain,
        macros: {
          protein: {
            grams: proteinGrams,
            calories: proteinCalories,
          },
          carbs: {
            grams: carbGrams,
            calories: carbCalories,
          },
          fat: {
            grams: fatGrams,
            calories: fatCalories,
          },
        },
      },
    });
  } catch (error) {
    console.error('TDEE Calculation Error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
