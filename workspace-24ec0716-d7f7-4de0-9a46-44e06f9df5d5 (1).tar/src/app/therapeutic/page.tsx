import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Pill, AlertTriangle, ArrowRight, BookOpen } from 'lucide-react';
import Link from 'next/link';

export default function TherapeuticPage() {
  const topics = [
    {
      title: 'PCOS Management',
      subtitle: 'Insulin Resistance and Hormonal Balance',
      description: 'Understand the pathophysiology: how insulin resistance drives ovarian androgen production. Learn nutritional strategies for insulin sensitization.',
      icon: Pill,
      href: '/therapeutic/pcos',
      color: 'bg-purple-100 text-purple-700 dark:bg-purple-900/20 dark:text-purple-400',
      articleCount: 4,
    },
    {
      title: 'Diabetes',
      subtitle: 'Blood Glucose Regulation',
      description: 'Deep dive into type 1 and type 2 diabetes pathophysiology, insulin mechanisms, and evidence-based nutritional interventions.',
      icon: Pill,
      href: '/therapeutic/diabetes',
      color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400',
      articleCount: 3,
    },
    {
      title: 'Hypertension',
      subtitle: 'Blood Pressure Regulation',
      description: 'Beyond sodium restriction. Explore the sodium-potassium ratio, nitric oxide signaling, and how lifestyle affects blood pressure.',
      icon: Pill,
      href: '/therapeutic/hypertension',
      color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/20 dark:text-rose-400',
      articleCount: 2,
    },
    {
      title: 'Gut Health & IBS',
      subtitle: 'The Microbiome and Digestion',
      description: 'The gut-brain axis, FODMAPs, and how stress affects motility. Learn to manage IBS through understanding, not elimination.',
      icon: Pill,
      href: '/therapeutic/gut-health',
      color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400',
      articleCount: 5,
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-muted/30">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6" variant="secondary">
              <Pill className="w-3 h-3 mr-2" />
              Therapeutic Nutrition
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Managing Conditions with <span className="gradient-text">Science</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Evidence-based insights into managing health conditions through nutritional understanding. Learn the pathophysiology to better advocate for yourself in clinical settings.
            </p>
          </div>
        </div>
      </section>

      {/* Important Disclaimer */}
      <section className="py-12">
        <div className="container-custom">
          <Card className="border-amber-200 bg-amber-50/50 dark:border-amber-900/50 dark:bg-amber-950/20">
            <CardContent className="p-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 rounded-full bg-amber-200 dark:bg-amber-900/50 flex items-center justify-center flex-shrink-0">
                  <AlertTriangle className="w-6 h-6 text-amber-700 dark:text-amber-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-amber-900 dark:text-amber-100 mb-2">
                    Important Medical Disclaimer
                  </h3>
                  <p className="text-sm text-amber-800 dark:text-amber-200 leading-relaxed">
                    The content in this section is for educational purposes only and is not intended to be a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified healthcare provider with any questions you may have regarding a medical condition. Never disregard professional medical advice or delay in seeking it because of something you have read on this website.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Topics Grid */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {topics.map((topic) => (
              <Link key={topic.title} href={topic.href} className="group">
                <Card className="h-full transition-all duration-300 hover:shadow-lg hover:border-primary/50 hover:-translate-y-1">
                  <CardHeader>
                    <div className={`w-14 h-14 rounded-xl ${topic.color} flex items-center justify-center mb-4`}>
                      <topic.icon className="w-7 h-7" />
                    </div>
                    <CardTitle className="group-hover:text-primary transition-colors">
                      {topic.title}
                    </CardTitle>
                    <CardDescription className="text-base font-medium">
                      {topic.subtitle}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                      {topic.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary" className="text-xs">
                        <BookOpen className="w-3 h-3 mr-1" />
                        {topic.articleCount} articles
                      </Badge>
                      <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Approach */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">
              Our Approach to Therapeutic Nutrition
            </h2>
            <div className="space-y-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">Pathophysiology-First</h3>
                  <p className="text-sm text-muted-foreground">
                    We explain the underlying mechanisms—how conditions develop at the physiological level—so you can understand the "why" behind recommendations.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">Evidence-Based</h3>
                  <p className="text-sm text-muted-foreground">
                    Every recommendation is backed by peer-reviewed research. We cite our sources so you can dive deeper into the science.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">Not Prescriptive</h3>
                  <p className="text-sm text-muted-foreground">
                    This is educational content, not medical advice. Our goal is to empower you with knowledge to have more informed conversations with your healthcare providers.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
