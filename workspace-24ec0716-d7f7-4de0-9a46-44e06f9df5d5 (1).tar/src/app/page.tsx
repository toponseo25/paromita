import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Brain, Activity, Sparkles, BookOpen, Calculator, Search, TrendingUp, Pill } from 'lucide-react';
import Link from 'next/link';
import { generateMetadata } from '@/lib/metadata';

export const metadata = generateMetadata({
  title: 'Decoding Your Biology, Fueling Your Life',
  description: 'Stop guessing. Start understanding. We translate the latest research in applied physiology into actionable strategies for how you eat, move, and live.',
  path: '/',
});

export default function HomePage() {
  const featuredArticles = [
    {
      id: 1,
      title: 'The Odyssey of an Apple: Tracing the Path from Bite to Biology',
      description: 'Follow an apple through the intricate journey of digestion—from your first bite to the cellular level where it becomes energy.',
      category: 'Digestive Physiology',
      icon: Brain,
      readTime: '8 min',
      href: '/articles/the-odyssey-of-an-apple',
    },
    {
      id: 2,
      title: 'Why You Feel Tired After Lunch: The Science of Post-Prandial Somnolence',
      description: 'It\'s not just about blood flow. Explore the insulin-tryptophan connection and how glucose affects your brain\'s wakefulness switch.',
      category: 'Hormonal Health',
      icon: Activity,
      readTime: '6 min',
      href: '/articles/why-you-feel-tired-after-lunch',
    },
    {
      id: 3,
      title: 'Muscle Protein Synthesis Explained: Repair and Rebuild',
      description: 'Understand the mTOR pathway, the leucine threshold, and how your body repairs muscle after exercise.',
      category: 'Performance',
      icon: Sparkles,
      readTime: '10 min',
      href: '/articles/muscle-protein-synthesis-explained',
    },
  ];

  const pillars = [
    {
      title: 'Physiology 101',
      subtitle: 'How Your Body Actually Works',
      description: 'Digestive mechanics, metabolic processes, hormonal signaling, and cardiovascular function explained.',
      icon: Brain,
      href: '/fundamentals',
      color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400',
    },
    {
      title: 'Nutrition Science',
      subtitle: 'Fueling the Machine',
      description: 'Macronutrients, micronutrients, hydration, and supplements decoded with evidence-based research.',
      icon: Activity,
      href: '/nutrition',
      color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400',
    },
    {
      title: 'Clinical Corner',
      subtitle: 'Managing Conditions with Science',
      description: 'Evidence-based insights on PCOS, diabetes, hypertension, and gut health management.',
      icon: Pill,
      href: '/therapeutic',
      color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/20 dark:text-rose-400',
    },
  ];

  const quickLinks = [
    { icon: Calculator, label: 'TDEE Calculator', href: '/resources', description: 'Calculate your daily energy needs' },
    { icon: BookOpen, label: 'Glossary', href: '/resources/glossary', description: 'Understand the terminology' },
    { icon: Search, label: 'Research Radar', href: '/research', description: 'Latest 2025 trends and studies' },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-background via-background to-muted/30">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(66,153,225,0.05),transparent_50%)]" />
        <div className="container-custom py-20 md:py-32 relative">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6" variant="secondary">
              <Sparkles className="w-3 h-3 mr-2" />
              Evidence-Based Health Education
            </Badge>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
              Stop Guessing.
              <br />
              <span className="gradient-text">Start Understanding.</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
              Nutrition advice isn't about magic; it's about mechanism. We translate the latest research in applied physiology into actionable strategies for how you eat, move, and live.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="text-base px-8">
                <Link href="/articles">
                  <BookOpen className="w-5 h-5 mr-2" />
                  Explore Articles
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="text-base px-8">
                <Link href="/about">
                  Learn About the Science
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Content Section */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              The Fundamentals
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Start with the building blocks. These foundational concepts will give you the framework to understand how your body works.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {pillars.map((pillar) => (
              <Link key={pillar.title} href={pillar.href} className="group">
                <Card className="h-full transition-all duration-300 hover:shadow-lg hover:border-primary/50 hover:-translate-y-1">
                  <CardHeader>
                    <div className={`w-14 h-14 rounded-xl ${pillar.color} flex items-center justify-center mb-4`}>
                      <pillar.icon className="w-7 h-7" />
                    </div>
                    <CardTitle className="group-hover:text-primary transition-colors">
                      {pillar.title}
                    </CardTitle>
                    <CardDescription className="text-base font-medium">
                      {pillar.subtitle}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {pillar.description}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Articles */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container-custom">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12">
            <div>
              <Badge variant="secondary" className="mb-4">Latest Articles</Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-2">
                Deep Dives into Physiology
              </h2>
              <p className="text-muted-foreground max-w-2xl">
                Mechanism-first explanations that give you the "why" behind health advice.
              </p>
            </div>
            <Button asChild variant="outline" className="mt-4 md:mt-0">
              <Link href="/articles">
                View All Articles
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredArticles.map((article) => (
              <Card key={article.id} className="h-full flex flex-col">
                <CardHeader className="flex-1">
                  <div className="flex items-center justify-between mb-4">
                    <Badge variant="secondary" className="text-xs">
                      {article.category}
                    </Badge>
                    <span className="text-xs text-muted-foreground flex items-center">
                      <BookOpen className="w-3 h-3 mr-1" />
                      {article.readTime}
                    </span>
                  </div>
                  <CardTitle className="text-xl mb-3 line-clamp-2 hover:text-primary transition-colors">
                    <Link href={article.href}>
                      {article.title}
                    </Link>
                  </CardTitle>
                  <CardDescription className="text-sm leading-relaxed">
                    {article.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button asChild variant="ghost" className="w-full justify-start group">
                    <Link href={article.href}>
                      Read Article
                      <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Resources */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Quick Tools & Resources
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Practical tools to help you understand and apply physiological principles.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {quickLinks.map((link) => (
              <Link key={link.label} href={link.href} className="group">
                <Card className="h-full transition-all duration-300 hover:shadow-lg hover:border-primary/50">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
                        <link.icon className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1 group-hover:text-primary transition-colors">
                          {link.label}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {link.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Research Radar Teaser */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-6">
              <TrendingUp className="w-3 h-3 mr-2" />
              2025 Updates
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Research Radar
            </h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Stay current with the latest breakthroughs in chrononutrition, gut health science, and performance research. We separate the hype from the evidence.
            </p>
            <Button asChild size="lg" variant="outline" className="text-base px-8">
              <Link href="/research">
                <Search className="w-5 h-5 mr-2" />
                Explore Research Radar
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <Card className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground border-0 overflow-hidden">
            <CardContent className="p-8 md:p-12 text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Decoding Your Biology, Fueling Your Life
              </h2>
              <p className="text-lg mb-8 max-w-2xl mx-auto opacity-90">
                Join thousands of curious minds who've stopped guessing and started understanding the science of their own bodies.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" variant="secondary" className="text-base px-8">
                  <BookOpen className="w-5 h-5 mr-2" />
                  Start Reading
                </Button>
                <Button size="lg" variant="outline" className="text-base px-8 bg-transparent border-primary-foreground/30 hover:bg-primary-foreground/10">
                  About the Science
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
