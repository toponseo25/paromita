import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dumbbell, Clock, ArrowLeft, BookOpen } from 'lucide-react';
import Link from 'next/link';

export default function ArticlePage() {
  const articleData = {
    title: 'Muscle Protein Synthesis Explained: Repair and Rebuild',
    subtitle: 'The Physiology of Building the Machine',
    author: 'Paromita',
    publishDate: 'January 2025',
    readTime: '10 min read',
    category: 'Performance',
  };

  return (
    <div className="min-h-screen">
      <article>
        <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-muted/30">
          <div className="container-custom">
            <Link href="/articles" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Articles
            </Link>

            <div className="max-w-4xl mx-auto">
              <Badge variant="secondary" className="mb-6">
                <Dumbbell className="w-3 h-3 mr-2" />
                {articleData.category}
              </Badge>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                {articleData.title}
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-8">
                {articleData.subtitle}
              </p>
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  {articleData.readTime}
                </span>
                <span>•</span>
                <span>{articleData.publishDate}</span>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-24">
          <div className="container-custom">
            <div className="max-w-3xl mx-auto prose prose-lg">
              <div className="mb-12">
                <p className="text-xl text-muted-foreground leading-relaxed mb-6">
                  You lift the weight. You feel the burn. But the gym is not where muscle is built; the gym is where muscle is broken.
                </p>
                <p className="text-lg leading-relaxed">
                  The actual building happens in the hours and days that follow, through a microscopic process called <strong>Muscle Protein Synthesis (MPS)</strong>. Understanding MPS is the key to stopping the guessing game with your post-workout shake.
                </p>
              </div>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">The Trigger: Mechanical Tension</h2>
                  <p className="leading-relaxed mb-4">
                    Muscle growth begins with a stimulus. When you lift weights, you create micro-tears in the sarcomeres (the contractile units of muscle). This mechanical stress is sensed by the cell, signaling that the current structure is insufficient to handle the load.
                  </p>
                  <div className="bg-primary/5 border-l-4 border-primary p-4 mt-4">
                    <p className="text-sm font-medium leading-relaxed">Adaptation is necessary.</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">The Master Switch: mTOR</h2>
                  <p className="leading-relaxed mb-4">
                    The central regulator of cell growth is a protein complex called <strong>mTOR</strong> (Mammalian Target of Rapamycin). Think of mTOR as the foreman of a construction site.
                  </p>
                  <div className="bg-primary/5 border-l-4 border-primary p-4">
                    <p className="text-sm font-medium leading-relaxed">When mTOR is activated, it signals the cell to begin assembling new proteins.</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">The Fuel: Amino Acids and the Leucine Threshold</h2>
                  <p className="leading-relaxed mb-4">To build the wall, you need bricks. In the body, these bricks are amino acids derived from dietary protein.</p>
                  
                  <div className="space-y-4">
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Leucine:</h3>
                      <p className="text-sm leading-relaxed">Of the 20 amino acids, Leucine is special. It acts as the "ignition key" for the mTOR engine.</p>
                    </div>
                    
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">The Threshold:</h3>
                      <p className="text-sm leading-relaxed">Research indicates there is a "Leucine Threshold"—you need roughly 2.5 to 3 grams of Leucine in a single meal to fully trigger MPS.</p>
                    </div>

                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Practical Amount:</h3>
                      <p className="text-sm leading-relaxed">This amount is typically found in 25-30g of high-quality animal protein (whey, eggs, chicken) or higher amounts of plant protein.</p>
                    </div>

                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Drip vs. Flood:</h3>
                      <p className="text-sm leading-relaxed">Eating 5g of protein every hour won't trigger the threshold. You need the "flood" of amino acids to flip the switch.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">The Process: Transcription and Translation</h2>
                  <p className="leading-relaxed mb-4">Once triggered:</p>
                  
                  <div className="space-y-4">
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Transcription:</h3>
                      <p className="text-sm leading-relaxed">The DNA in the muscle cell nucleus opens up and copies the instructions for building new muscle proteins onto a molecule called mRNA.</p>
                    </div>

                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Translation:</h3>
                      <p className="text-sm leading-relaxed">The mRNA travels to the ribosomes (the cell's factories). The ribosomes read the instructions and assemble amino acids into new strands of actin and myosin (contractile proteins).</p>
                    </div>
                  </div>

                  <div className="mt-4 bg-primary/5 border-l-4 border-primary p-4">
                    <p className="text-sm font-medium leading-relaxed">Result: The muscle fiber becomes thicker and stronger (hypertrophy).</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">The Refractory Period</h2>
                  <p className="leading-relaxed mb-4">Interestingly, you cannot keep the MPS switch "on" indefinitely.</p>
                  
                  <div className="bg-muted p-4 rounded-lg mb-4">
                    <p className="text-sm leading-relaxed">After a protein-rich meal, MPS rises for about 3 hours and then drops, even if amino acids are still high in the blood. This is the "muscle-full" effect.</p>
                  </div>

                  <div className="bg-primary/5 border-l-4 border-primary p-4">
                    <h3 className="font-semibold mb-2">Strategy:</h3>
                    <p className="text-sm leading-relaxed">This is why eating protein every 3-5 hours (pulsing) is more effective than eating all your protein in one massive meal.</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-12 bg-gradient-to-br from-primary/5 to-muted/30">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4">The Takeaway</h2>
                  <p className="text-lg leading-relaxed">
                    Muscle isn't built by accident. It is built by adequate mechanical tension followed by strategic protein pulses that hit the Leucine threshold, activating mTOR to repair the damage stronger than before.
                  </p>
                </CardContent>
              </Card>

              <div className="border-t pt-8">
                <h3 className="font-semibold mb-4 flex items-center">
                  <BookOpen className="w-4 h-4 mr-2" />
                  References
                </h3>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li className="ml-4 list-disc">Areta, J. L., et al. (2013). Timing and distribution of protein ingestion... <em>The Journal of Physiology</em>.</li>
                  <li className="ml-4 list-disc">Moore, D. R., et al. (2009). Ingested protein dose response... <em>The American Journal of Clinical Nutrition</em>.</li>
                  <li className="ml-4 list-disc">Phillips, S. M., & Van Loon, L. J. C. (2011). Dietary protein for athletes... <em>Nutrients</em>.</li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </article>
    </div>
  );
}
