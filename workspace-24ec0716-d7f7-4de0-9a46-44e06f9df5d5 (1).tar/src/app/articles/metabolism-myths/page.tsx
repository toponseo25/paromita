import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Zap, Clock, ArrowLeft, BookOpen } from 'lucide-react';
import Link from 'next/link';

export default function ArticlePage() {
  const articleData = {
    title: 'Metabolism Myths: You Can\'t Boost a Furnace That Doesn\'t Exist',
    subtitle: 'The Truth About Your Metabolic Engine',
    author: 'Paromita',
    publishDate: 'January 2025',
    readTime: '7 min read',
    category: 'Metabolism',
  };

  return (
    <div className="min-h-screen">
      <article>
        <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-muted/30">
          <div className="container-custom">
            <Link href="/articles" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Articles
            </Link>

            <div className="max-w-4xl mx-auto">
              <Badge variant="secondary" className="mb-6">
                <Zap className="w-3 h-3 mr-2" />
                {articleData.category}
              </Badge>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                {articleData.title}
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-8">
                {articleData.subtitle}
              </p>
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  {articleData.readTime}
                </span>
                <span>•</span>
                <span>{articleData.publishDate}</span>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-24">
          <div className="container-custom">
            <div className="max-w-3xl mx-auto prose prose-lg">
              <div className="mb-12">
                <p className="text-xl text-muted-foreground leading-relaxed mb-6">
                  "Boost your metabolism with this tea!" "Ignite your fat-burning furnace!"
                </p>
                <p className="text-lg leading-relaxed">
                  The marketing language around metabolism is fiery, exciting, and scientifically bankrupt. Your metabolism isn't a furnace; it's a series of chemical reactions governed by the laws of thermodynamics. Let's strip away the hype and look at the math.
                </p>
              </div>

              <Card className="mb-8 bg-primary/5">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4">The Equation: TDEE</h2>
                  <p className="leading-relaxed mb-4">Your metabolism is quantifiable. It is the sum of all energy your body expends in a day, known as Total Daily Energy Expenditure (TDEE).</p>
                  <div className="bg-background p-6 rounded-lg text-center">
                    <p className="text-2xl font-mono font-bold">TDEE = BMR + TEF + NEAT + EAT</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">1. BMR (Basal Metabolic Rate) — ~60-70%</h2>
                  <p className="leading-relaxed mb-4">This is the energy cost of keeping the lights on. Even if you stayed in bed all day, your body burns calories to pump ions across cell membranes, beat your heart, and expand your lungs.</p>
                  
                  <div className="bg-muted p-4 rounded-lg mb-4">
                    <h3 className="font-semibold mb-2">The Myth: "I have a slow metabolism"</h3>
                    <p className="text-sm leading-relaxed">The Science: When adjusted for body size and muscle mass, BMR varies very little between people (about 10-15%). The larger you are, the higher your BMR.</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">2. TEF (Thermic Effect of Food) — ~10%</h2>
                  <p className="leading-relaxed mb-4">Digestion costs energy. Breaking down food releases heat.</p>
                  
                  <div className="bg-muted p-4 rounded-lg mb-4">
                    <h3 className="font-semibold mb-2">The Protein Advantage:</h3>
                    <p className="text-sm leading-relaxed">Protein has the highest TEF (20-30%). If you eat 100 calories of protein, your body uses 20-30 of them just to process it. Fat has a tiny TEF (0-3%).</p>
                  </div>

                  <div className="bg-primary/5 border-l-4 border-primary p-4">
                    <p className="text-sm font-medium leading-relaxed">The "Boost": Eating more protein does technically "boost" your metabolic rate via TEF, but not enough to melt away pounds on its own.</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">3. NEAT (Non-Exercise Activity Thermogenesis) — ~15% (highly variable)</h2>
                  <p className="leading-relaxed mb-4">This is the secret weapon. NEAT includes fidgeting, standing, walking to the car, and typing.</p>
                  
                  <div className="bg-muted p-4 rounded-lg mb-4">
                    <h3 className="font-semibold mb-2">The Variance:</h3>
                    <p className="text-sm leading-relaxed">Research shows that "naturally skinny" people often have high NEAT levels—they unconsciously move more throughout the day.</p>
                  </div>

                  <div className="bg-muted p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">The Numbers:</h3>
                    <p className="text-sm leading-relaxed">The difference between a fidgety person and a sedentary person can be up to 800 calories a day.</p>
                  </div>

                  <div className="mt-4 bg-primary/5 border-l-4 border-primary p-4">
                    <h3 className="font-semibold mb-2">The Action:</h3>
                    <p className="text-sm leading-relaxed">You can't easily change your BMR, but you can double your NEAT by using a standing desk or pacing while on the phone.</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">4. EAT (Exercise Activity Thermogenesis) — ~5%</h2>
                  <p className="leading-relaxed mb-4">Surprisingly, structured exercise (the hour at the gym) makes up a small fraction of total burn for most people.</p>
                </CardContent>
              </Card>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">Can You "Boost" It?</h2>
                  
                  <div className="space-y-3">
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Spicy Food/Green Tea:</h3>
                      <p className="text-sm leading-relaxed">The effect is negligible (maybe 10-50 calories).</p>
                    </div>

                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Cold Water:</h3>
                      <p className="text-sm leading-relaxed">Minimal effect.</p>
                    </div>

                    <div className="bg-primary/5 p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Muscle Mass — The Only Real "Boost":</h3>
                      <p className="text-sm leading-relaxed">Muscle tissue is more metabolically active than fat tissue. Adding 10lbs of muscle might increase your daily BMR by ~60-100 calories.</p>
                    </div>

                    <div className="bg-primary/5 border-l-4 border-primary p-4">
                      <p className="text-sm font-medium leading-relaxed">It sounds small, but over a year, that's substantial.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-12 bg-gradient-to-br from-primary/5 to-muted/30">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4">Conclusion</h2>
                  <p className="text-lg leading-relaxed mb-4">
                    Stop looking for a metabolic switch to flip.
                  </p>
                  <p className="text-lg leading-relaxed">
                    If you want to increase your output, the science points to two things: Build more muscle (to raise BMR) and move more during the day (to raise NEAT).
                  </p>
                </CardContent>
              </Card>

              <div className="border-t pt-8">
                <h3 className="font-semibold mb-4 flex items-center">
                  <BookOpen className="w-4 h-4 mr-2" />
                  References
                </h3>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li className="ml-4 list-disc">Levine, J. A., et al. (2005). Inter-individual variation in posture allocation... <em>Science</em>.</li>
                  <li className="ml-4 list-disc">Ravussin, E., & Bogardus, C. (1989). Relationship of genetics... <em>Journal of Clinical Investigation</em>.</li>
                  <li className="ml-4 list-disc">Tremblay, A., et al. (2009). Thermic effect of food... <em>Nutrition Reviews</em>.</li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </article>
    </div>
  );
}
