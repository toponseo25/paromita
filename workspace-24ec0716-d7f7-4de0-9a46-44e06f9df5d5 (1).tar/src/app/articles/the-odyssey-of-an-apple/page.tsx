import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Brain, Clock, ArrowLeft, BookOpen } from 'lucide-react';
import Link from 'next/link';
import { notFound } from 'next/navigation';

export default function ArticlePage() {
  const articleData = {
    title: 'The Odyssey of an Apple: Tracing the Path from Bite to Biology',
    subtitle: 'A Physiological Journey',
    author: 'Paromita',
    publishDate: 'January 2025',
    readTime: '8 min read',
    category: 'Digestive Physiology',
  };

  return (
    <div className="min-h-screen">
      {/* Article Header */}
      <article>
        <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-muted/30">
          <div className="container-custom">
            <Link href="/articles" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Articles
            </Link>

            <div className="max-w-4xl mx-auto">
              <Badge variant="secondary" className="mb-6">
                <Brain className="w-3 h-3 mr-2" />
                {articleData.category}
              </Badge>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                {articleData.title}
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-8">
                {articleData.subtitle}
              </p>
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  {articleData.readTime}
                </span>
                <span>•</span>
                <span>{articleData.publishDate}</span>
              </div>
            </div>
          </div>
        </section>

        {/* Article Content */}
        <section className="py-16 md:py-24">
          <div className="container-custom">
            <div className="max-w-3xl mx-auto prose prose-lg">
              {/* Introduction */}
              <div className="mb-12">
                <p className="text-xl text-muted-foreground leading-relaxed mb-6">
                  You pick up a crisp, red apple and take a bite. It tastes sweet, tart, and refreshing. You swallow. For you, the experience is over. For your body, the work has just begun.
                </p>
                <p className="text-lg leading-relaxed mb-6">
                  The transformation of this fruit into the energy that powers your thoughts and the structures that repair your cells is a masterpiece of physiological engineering. Let's follow the apple.
                </p>
              </div>

              {/* Phase 1 */}
              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">
                    Phase 1: The Oral Cavity – Demolition and Priming
                  </h2>
                  <p className="leading-relaxed mb-4">
                    Before you even took that bite, your brain initiated the <strong>cephalic phase</strong> of digestion. The mere sight of the apple signaled your salivary glands to release saliva.
                  </p>
                  <div className="bg-muted p-4 rounded-lg mb-4">
                    <h3 className="font-semibold mb-2">Mechanical Digestion:</h3>
                    <p className="text-sm leading-relaxed">
                      Your teeth rupture the apple's skin, breaking the cellular matrix to increase surface area.
                    </p>
                  </div>
                  <div className="bg-muted p-4 rounded-lg mb-4">
                    <h3 className="font-semibold mb-2">Chemical Digestion:</h3>
                    <p className="text-sm leading-relaxed">
                      Saliva contains <strong>amylase</strong>, an enzyme that begins snipping the long chains of starch into simpler sugars like maltose. It also contains lingual lipase, though its action on the apple is minimal.
                    </p>
                  </div>
                  <p className="leading-relaxed">
                    The tongue manipulates this mixture into a <strong>bolus</strong>—a cohesive ball ready for transport.
                  </p>
                </CardContent>
              </Card>

              {/* Phase 2 */}
              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">
                    Phase 2: The Esophagus and Stomach – The Acid Bath
                  </h2>
                  <p className="leading-relaxed mb-4">
                    You swallow. The bolus enters the esophagus, a muscular tube that uses rhythmic contractions called <strong>peristalsis</strong> to force the food down to the stomach.
                  </p>
                  <p className="leading-relaxed mb-4">
                    Upon entry through the Lower Esophageal Sphincter (LES), the apple enters a hostile environment. The stomach lining secretes <strong>Hydrochloric Acid (HCl)</strong>, dropping the pH to between 1.5 and 3.5.
                  </p>
                  <div className="space-y-3">
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Sterilization:</h3>
                      <p className="text-sm leading-relaxed">
                        This acid kills most bacteria lingering on the apple skin.
                      </p>
                    </div>
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Protein Unfolding:</h3>
                      <p className="text-sm leading-relaxed">
                        While apples are low in protein, the acid denatures what little is there, uncoiling the complex structures so enzymes can access them.
                      </p>
                    </div>
                  </div>
                  <p className="leading-relaxed mt-4">
                    The stomach churns this mixture into a semi-liquid paste called <strong>chyme</strong>.
                  </p>
                </CardContent>
              </Card>

              {/* Phase 3 */}
              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">
                    Phase 3: The Small Intestine – The Extraction Zone
                  </h2>
                  <p className="leading-relaxed mb-4">
                    The stomach releases the chyme into the <strong>duodenum</strong>, the first part of the small intestine. This is the main event.
                  </p>
                  <div className="space-y-3">
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Neutralization:</h3>
                      <p className="text-sm leading-relaxed">
                        The pancreas squirts bicarbonate to neutralize the acid, protecting the delicate intestinal lining.
                      </p>
                    </div>
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Enzymatic Attack:</h3>
                      <p className="text-sm leading-relaxed">
                        Pancreatic amylase continues breaking down the carbohydrates.
                      </p>
                    </div>
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Absorption:</h3>
                      <p className="text-sm leading-relaxed">
                        The intestinal walls are lined with millions of finger-like projections called <strong>villi</strong>. Here, the magic of absorption happens.
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 bg-primary/5 border-l-4 border-primary p-4">
                    <p className="text-sm leading-relaxed">
                      <strong>Fructose:</strong> The primary sugar in the apple is absorbed via specific transporters (GLUT5) using a process called facilitated diffusion.
                    </p>
                  </div>
                  <div className="mt-3 bg-primary/5 border-l-4 border-primary p-4">
                    <p className="text-sm leading-relaxed">
                      <strong>Vitamins:</strong> Vitamin C molecules slip through the intestinal wall and into the bloodstream, ready to act as antioxidants.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Phase 4 */}
              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">
                    Phase 4: The Large Intestine – The Microbiome Feast
                  </h2>
                  <p className="leading-relaxed mb-4">
                    What's left? Mostly water and indigestible fiber (pectin and cellulose). This enters the colon, a dark, anaerobic chamber teeming with trillions of bacteria—your <strong>microbiome</strong>.
                  </p>
                  <div className="space-y-3">
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Fermentation:</h3>
                      <p className="text-sm leading-relaxed">
                        These bacteria cannot digest the fiber, so they ferment it. This process produces Short-Chain Fatty Acids (SCFAs) like <strong>butyrate</strong>.
                      </p>
                    </div>
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">The Payoff:</h3>
                      <p className="text-sm leading-relaxed">
                        Butyrate fuels the cells of your colon, reducing inflammation and keeping the gut barrier strong. In a way, you fed your bacteria, and they, in turn, fed you.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Conclusion */}
              <Card className="mb-12 bg-gradient-to-br from-primary/5 to-muted/30">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4">
                    Conclusion
                  </h2>
                  <p className="text-lg leading-relaxed mb-4">
                    The apple is no longer an apple. It is now glucose fueling your brain, Vitamin C protecting your DNA, and butyrate nourishing your gut.
                  </p>
                  <p className="text-xl font-semibold text-primary">
                    This is digestion: the alchemy of life.
                  </p>
                </CardContent>
              </Card>

              {/* References */}
              <div className="border-t pt-8">
                <h3 className="font-semibold mb-4 flex items-center">
                  <BookOpen className="w-4 h-4 mr-2" />
                  References
                </h3>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li className="ml-4 list-disc">
                    Guyton, A. C., & Hall, J. E. (2020). <em>Medical Physiology</em> (14th ed.). Elsevier.
                  </li>
                  <li className="ml-4 list-disc">
                    Barrett, K. E., et al. (2021). <em>Ganong's Review of Medical Physiology</em> (26th ed.). McGraw-Hill Education.
                  </li>
                  <li className="ml-4 list-disc">
                    Human Microbiome Project Consortium. (2019). The integrative Human Microbiome Project. <em>Nature</em>.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </article>
    </div>
  );
}
