import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Clock, ArrowRight, Brain, Activity, Dumbbell, Zap, Heart } from 'lucide-react';
import Link from 'next/link';
import { generateMetadata } from '@/lib/metadata';

export const metadata = generateMetadata({
  title: 'Article Library - Deep Dives into Physiology',
  description: 'Comprehensive library of evidence-based health articles. Explore deep dives into digestive physiology, metabolism, hormonal health, sports nutrition, and stress physiology. Mechanism-first explanations backed by peer-reviewed research.',
  path: '/articles',
});

export default function ArticlesPage() {
  const articles = [
    {
      id: 'the-odyssey-of-an-apple',
      title: 'The Odyssey of an Apple: Tracing Path from Bite to Biology',
      description: 'You pick up a crisp, red apple and take a bite. You swallow. For you, the experience is over. For your body, the work has just begun. Follow the apple through digestion.',
      category: 'Digestive Physiology',
      icon: Brain,
      readTime: '8 min',
      featured: true,
    },
    {
      id: 'why-you-feel-tired-after-lunch',
      title: 'Why You Feel Tired After Lunch: The Science of the Food Coma',
      description: 'Is it just because blood rushed to your stomach? Not exactly. The reality involves a complex interplay of hormones, amino acids, and brain chemistry.',
      category: 'Hormonal Health',
      icon: Activity,
      readTime: '6 min',
      featured: true,
    },
    {
      id: 'muscle-protein-synthesis-explained',
      title: 'Muscle Protein Synthesis Explained: Repair and Rebuild',
      description: 'The gym is where muscle is broken; the actual building happens in the hours and days that follow. Understand the microscopic process of MPS.',
      category: 'Performance',
      icon: Dumbbell,
      readTime: '10 min',
      featured: true,
    },
    {
      id: 'metabolism-myths',
      title: 'Metabolism Myths: You Can\'t Boost a Furnace That Doesn\'t Exist',
      description: 'Your metabolism isn\'t a furnace—it\'s a series of chemical reactions governed by the laws of thermodynamics. Let\'s strip away the hype.',
      category: 'Metabolism',
      icon: Zap,
      readTime: '7 min',
      featured: true,
    },
    {
      id: 'cortisol-and-cravings',
      title: 'The Biology of Comfort Food: Why Stress Demands Sugar',
      description: 'This isn\'t a failure of willpower; it\'s a survival mechanism orchestrated by your hormones. Explore the HPA axis and stress eating.',
      category: 'Stress Physiology',
      icon: Heart,
      readTime: '9 min',
      featured: true,
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-muted/30">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6" variant="secondary">
              <BookOpen className="w-3 h-3 mr-2" />
              Article Library
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Deep Dives into <span className="gradient-text">Physiology</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Mechanism-first explanations that give you the "why" behind health advice. Every article is rooted in peer-reviewed research and translated for understanding.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Articles */}
      <section className="py-16 md:py-24">
        <div className="container-custom">
          <div className="mb-8">
            <h2 className="text-2xl md:text-3xl font-bold mb-2">
              Featured Articles
            </h2>
            <p className="text-muted-foreground">
              Start here for comprehensive deep dives into fundamental physiological concepts
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article) => (
              <Link key={article.id} href={`/articles/${article.id}`} className="group">
                <Card className="h-full flex flex-col transition-all duration-300 hover:shadow-lg hover:border-primary/50 hover:-translate-y-1">
                  <CardHeader className="flex-1">
                    <div className="flex items-center justify-between mb-4">
                      <Badge variant="secondary" className="text-xs flex items-center">
                        <article.icon className="w-3 h-3 mr-1" />
                        {article.category}
                      </Badge>
                      <span className="text-xs text-muted-foreground flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {article.readTime}
                      </span>
                    </div>
                    <CardTitle className="text-lg mb-3 group-hover:text-primary transition-colors line-clamp-2">
                      {article.title}
                    </CardTitle>
                    <CardDescription className="text-sm leading-relaxed line-clamp-3">
                      {article.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-primary group-hover:translate-x-1 transition-transform">
                      Read Article
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Reading Guide */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl md:text-3xl font-bold mb-8 text-center">
              How to Use These Articles
            </h2>
            <div className="space-y-4">
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">Start with the Fundamentals</h3>
                  <p className="text-sm text-muted-foreground">
                    Begin with "The Odyssey of an Apple" to understand digestion. This foundation will help you grasp concepts in later articles about metabolism and hormonal regulation.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">Follow Your Curiosity</h3>
                  <p className="text-sm text-muted-foreground">
                    Each article is self-contained. If you're curious about a specific topic—like why you get tired after lunch—jump right in. We'll explain the necessary concepts as we go.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">Reference as Needed</h3>
                  <p className="text-sm text-muted-foreground">
                    These articles are designed to be reference resources. Come back when you need a refresher on how a specific physiological mechanism works.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
