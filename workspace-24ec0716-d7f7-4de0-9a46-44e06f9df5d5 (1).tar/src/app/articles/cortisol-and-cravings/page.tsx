import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Heart, Clock, ArrowLeft, BookOpen } from 'lucide-react';
import Link from 'next/link';

export default function ArticlePage() {
  const articleData = {
    title: 'The Biology of Comfort Food: Why Stress Demands Sugar',
    subtitle: 'Understanding the Stress-Craving Connection',
    author: 'Paromita',
    publishDate: 'January 2025',
    readTime: '9 min read',
    category: 'Stress Physiology',
  };

  return (
    <div className="min-h-screen">
      <article>
        <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-muted/30">
          <div className="container-custom">
            <Link href="/articles" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Articles
            </Link>

            <div className="max-w-4xl mx-auto">
              <Badge variant="secondary" className="mb-6">
                <Heart className="w-3 h-3 mr-2" />
                {articleData.category}
              </Badge>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                {articleData.title}
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-8">
                {articleData.subtitle}
              </p>
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  {articleData.readTime}
                </span>
                <span>•</span>
                <span>{articleData.publishDate}</span>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-24">
          <div className="container-custom">
            <div className="max-w-3xl mx-auto prose prose-lg">
              <div className="mb-12">
                <p className="text-xl text-muted-foreground leading-relaxed mb-6">
                  You've had a terrible day. You're overwhelmed, anxious, and exhausted. You walk into the kitchen. Do you crave steamed broccoli?
                </p>
                <p className="text-lg leading-relaxed">
                  No. You crave ice cream, cookies, or pizza. This isn't a failure of willpower; it's a survival mechanism orchestrated by your hormones.
                </p>
              </div>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">The HPA Axis: The Stress Highway</h2>
                  <p className="leading-relaxed mb-4">
                    When your brain perceives stress, the Hypothalamus signals the Pituitary gland, which signals the Adrenal glands (the HPA axis). The result is a surge of <strong>Cortisol</strong>, the primary stress hormone.
                  </p>
                </CardContent>
              </Card>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">Evolutionary Mismatch</h2>
                  <p className="leading-relaxed mb-4">In the Paleolithic era, stress usually meant physical danger—a predator or a famine.</p>
                  
                  <div className="space-y-3">
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Fuel Mobilization:</h3>
                      <p className="text-sm leading-relaxed">Cortisol tells the liver to dump glucose into the bloodstream so muscles have fuel to fight or run.</p>
                    </div>

                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Insulin Inhibition:</h3>
                      <p className="text-sm leading-relaxed">Cortisol temporarily blocks insulin, keeping that sugar in the blood for immediate use.</p>
                    </div>

                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Appetite Stimulation:</h3>
                      <p className="text-sm leading-relaxed">Once the acute threat passes, the body thinks it has burned massive calories fleeing the tiger. Cortisol drives you to replenish those stores with the most energy-dense foods available: sugar and fat.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">The "Comfort" in Comfort Food</h2>
                  <p className="leading-relaxed mb-4">Why specifically sugar?</p>
                  
                  <div className="space-y-3">
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Brain Dampening:</h3>
                      <p className="text-sm leading-relaxed">Research shows that consuming sugar and fat actually dampens the stress response in the brain. It lowers the HPA axis activity.</p>
                    </div>

                    <div className="bg-primary/5 border-l-4 border-primary p-4">
                      <p className="text-sm font-medium leading-relaxed">In a literal sense, the cookie makes you feel better chemically. It is self-medication.</p>
                    </div>

                    <div className="bg-muted p-4 rounded-lg mt-3">
                      <h3 className="font-semibold mb-2">Reward Pathways:</h3>
                      <p className="text-sm leading-relaxed">Glucocorticoid (cortisol) receptors are dense in the brain's reward centers. High cortisol makes the brain more sensitive to the pleasure of sugar, reinforcing the habit loop.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">The Modern Problem: Chronic Stress</h2>
                  <p className="leading-relaxed mb-4">Today's stress is rarely physical. It's emails and deadlines.</p>
                  
                  <div className="bg-primary/5 border-l-4 border-primary p-4 mb-4">
                    <h3 className="font-semibold mb-2">The Trap:</h3>
                    <p className="text-sm leading-relaxed">You get stressed (Cortisol rises) → You dump glucose into the blood → You don't run, so you don't burn it → You eat sugar (to soothe the stress) → Insulin spikes to store the excess energy.</p>
                  </div>

                  <div className="space-y-3">
                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Visceral Fat:</h3>
                      <p className="text-sm leading-relaxed">Cortisol specifically encourages fat storage in the abdominal area (visceral fat), which has more cortisol receptors.</p>
                    </div>

                    <div className="bg-muted p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">Inflammatory Cycle:</h3>
                      <p className="text-sm leading-relaxed">This fat is inflammatory, creating a cycle of metabolic dysfunction.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-12 bg-gradient-to-br from-primary/5 to-muted/30">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-6">Breaking the Cycle</h2>
                  
                  <div className="space-y-4">
                    <div className="bg-background p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">1. Recognize the Signal</h3>
                      <p className="text-sm leading-relaxed">When the craving hits, ask: "Am I hungry, or am I stressed?"</p>
                    </div>

                    <div className="bg-background p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">2. Stress Management</h3>
                      <p className="text-sm leading-relaxed">Techniques like box breathing or a short walk can lower cortisol levels without the need for sugar.</p>
                    </div>

                    <div className="bg-background p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">3. Low-Glycemic Foods</h3>
                      <p className="text-sm leading-relaxed">Eating fiber and protein stabilizes blood sugar, preventing the hypoglycemic crash that often follows a stress-eating binge.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="border-t pt-8">
                <h3 className="font-semibold mb-4 flex items-center">
                  <BookOpen className="w-4 h-4 mr-2" />
                  References
                </h3>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li className="ml-4 list-disc">Tryon, M. S., et al. (2015). The effects of high sugar consumption... <em>Advances in Nutrition</em>.</li>
                  <li className="ml-4 list-disc">Pecoraro, N., et al. (2004). Stress, comfort food, and... <em>Journal of Neuroscience</em>.</li>
                  <li className="ml-4 list-disc">Tsigos, C., & Chrousos, G. P. (2002). Hypothalamic-pituitary-adrenal axis... <em>Annals of the New York Academy of Sciences</em>.</li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </article>
    </div>
  );
}
