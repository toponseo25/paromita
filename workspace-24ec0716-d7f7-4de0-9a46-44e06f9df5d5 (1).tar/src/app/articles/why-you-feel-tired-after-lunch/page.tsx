import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, Clock, ArrowLeft, BookOpen } from 'lucide-react';
import Link from 'next/link';

export default function ArticlePage() {
  const articleData = {
    title: 'Why You Feel Tired After Lunch: The Science of the Food Coma',
    subtitle: 'Understanding Post-Prandial Somnolence',
    author: 'Paromita',
    publishDate: 'January 2025',
    readTime: '6 min read',
    category: 'Hormonal Health',
  };

  return (
    <div className="min-h-screen">
      {/* Article Header */}
      <article>
        <section className="py-16 md:py-24 bg-gradient-to-br from-background via-background to-muted/30">
          <div className="container-custom">
            <Link href="/articles" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Articles
            </Link>

            <div className="max-w-4xl mx-auto">
              <Badge variant="secondary" className="mb-6">
                <Activity className="w-3 h-3 mr-2" />
                {articleData.category}
              </Badge>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                {articleData.title}
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-8">
                {articleData.subtitle}
              </p>
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  {articleData.readTime}
                </span>
                <span>•</span>
                <span>{articleData.publishDate}</span>
              </div>
            </div>
          </div>
        </section>

        {/* Article Content */}
        <section className="py-16 md:py-24">
          <div className="container-custom">
            <div className="max-w-3xl mx-auto prose prose-lg">
              {/* Introduction */}
              <div className="mb-12">
                <p className="text-xl text-muted-foreground leading-relaxed mb-6">
                  It's 2:00 PM. You had a sandwich and a soda for lunch. Now, your eyelids feel heavy, your focus is drifting, and all you want is a nap.
                </p>
                <p className="text-lg leading-relaxed">
                  We call it the "food coma," or scientifically, <strong>post-prandial somnolence</strong>. Is it just because blood rushed to your stomach? Not exactly. The reality involves a complex interplay of hormones, amino acids, and brain chemistry.
                </p>
              </div>

              {/* Myth Buster */}
              <Card className="mb-8 bg-amber-50/50 border-amber-200 dark:bg-amber-950/20 dark:border-amber-900/50">
                <CardContent className="p-6">
                  <h2 className="text-xl font-bold mb-4 text-amber-900 dark:text-amber-100">
                    Myth Buster: It's Not Just Blood Flow
                  </h2>
                  <p className="text-sm text-amber-800 dark:text-amber-200 leading-relaxed">
                    The old theory was that blood was diverted from the brain to the gut (splanchnic sequestration) to aid digestion, leaving the brain deprived. <strong>While blood flow to the gut does increase, the brain's blood supply is tightly regulated and remains relatively constant.</strong> The cause is biochemical, not hemodynamic.
                  </p>
                </CardContent>
              </Card>

              {/* Mechanism 1 */}
              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">
                    Mechanism 1: The Insulin-Tryptophan Connection
                  </h2>
                  <p className="leading-relaxed mb-4">
                    When you eat a meal high in carbohydrates (like bread and soda), your blood glucose spikes. In response, your pancreas releases <strong>insulin</strong> to shuttle that sugar into your cells.
                  </p>

                  <div className="bg-muted p-4 rounded-lg mb-4">
                    <h3 className="font-semibold mb-2">The Amino Acid Shuffle:</h3>
                    <p className="text-sm leading-relaxed">
                      Insulin also drives amino acids (the building blocks of protein) into your muscles—except for one: <strong>Tryptophan</strong>.
                    </p>
                  </div>

                  <div className="bg-muted p-4 rounded-lg mb-4">
                    <h3 className="font-semibold mb-2">The Open Gate:</h3>
                    <p className="text-sm leading-relaxed">
                      Usually, Tryptophan has to compete with other amino acids (like Leucine and Valine) to cross the Blood-Brain Barrier. But since insulin swept the competitors into the muscles, Tryptophan has a free pass to enter the brain.
                    </p>
                  </div>

                  <div className="bg-muted p-4 rounded-lg mb-4">
                    <h3 className="font-semibold mb-2">Serotonin Synthesis:</h3>
                    <p className="text-sm leading-relaxed">
                      Once in the brain, Tryptophan is converted into <strong>Serotonin</strong> (the "feel-good" neurotransmitter) and subsequently into <strong>Melatonin</strong> (the sleep hormone).
                    </p>
                  </div>

                  <div className="mt-4 bg-primary/5 border-l-4 border-primary p-4">
                    <p className="text-sm font-medium leading-relaxed">
                      Result: You feel happy, relaxed, and very, very sleepy.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Mechanism 2 */}
              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">
                    Mechanism 2: The Orexin Switch
                  </h2>
                  <p className="leading-relaxed mb-4">
                    Deep in the hypothalamus, a group of neurons produces a neuropeptide called <strong>Orexin</strong> (also known as Hypocretin). Orexin is crucial for wakefulness and alertness.
                  </p>

                  <div className="bg-muted p-4 rounded-lg mb-4">
                    <h3 className="font-semibold mb-2">Glucose Suppression:</h3>
                    <p className="text-sm leading-relaxed">
                      Research suggests that high levels of glucose in the blood can inhibit the activity of these orexin neurons.
                    </p>
                  </div>

                  <div className="mt-4 bg-primary/5 border-l-4 border-primary p-4">
                    <p className="text-sm font-medium leading-relaxed">
                      Essentially, the sugar spike turns off your brain's "stay awake" switch.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Mechanism 3 */}
              <Card className="mb-8">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-4 text-primary">
                    Mechanism 3: The Parasympathetic Shift
                  </h2>
                  <p className="leading-relaxed mb-4">
                    Digestion requires the body to be in a "Rest and Digest" state, governed by the <strong>parasympathetic nervous system</strong>.
                  </p>

                  <div className="bg-muted p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">Vagal Activation:</h3>
                    <p className="text-sm leading-relaxed">
                      Large meals activate the Vagus nerve, which signals the heart rate to slow down and the body to conserve energy for the task of digestion.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Action Plan */}
              <Card className="mb-12 bg-gradient-to-br from-primary/5 to-muted/30">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold mb-6">
                    Action Plan: How to Avoid the Crash
                  </h2>

                  <div className="space-y-4">
                    <div className="bg-background p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">1. Reduce Glycemic Load</h3>
                      <p className="text-sm leading-relaxed">
                        Choose complex carbs (whole grains, veggies) over simple sugars to prevent the massive insulin spike.
                      </p>
                    </div>

                    <div className="bg-background p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">2. Prioritize Protein</h3>
                      <p className="text-sm leading-relaxed">
                        While protein contains Tryptophan, it also provides the competing amino acids that prevent Tryptophan from flooding the brain.
                      </p>
                    </div>

                    <div className="bg-background p-4 rounded-lg">
                      <h3 className="font-semibold mb-2">3. Walk It Off</h3>
                      <p className="text-sm leading-relaxed">
                        A 10-minute walk post-lunch helps muscles soak up glucose without requiring as much insulin, blunting the somnolence effect.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* References */}
              <div className="border-t pt-8">
                <h3 className="font-semibold mb-4 flex items-center">
                  <BookOpen className="w-4 h-4 mr-2" />
                  References
                </h3>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li className="ml-4 list-disc">
                    Wells, A. S., et al. (1997). Effects of breakfast size on cardiovascular, hormonal, and psychological responses. <em>Physiology & Behavior</em>, 62(1), 79-84.
                  </li>
                  <li className="ml-4 list-disc">
                    Yamaguchi, M., et al. (2014). Effect of orexin on sleep/wakefulness. <em>Frontiers in Endocrinology</em>, 5, 210.
                  </li>
                  <li className="ml-4 list-disc">
                    Fernstrom, J. D. (2013). Large neutral amino acids: effects on brain function and behavior. <em>Journal of Nutrition</em>, 143(10), 1557S-1564S.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </article>
    </div>
  );
}
