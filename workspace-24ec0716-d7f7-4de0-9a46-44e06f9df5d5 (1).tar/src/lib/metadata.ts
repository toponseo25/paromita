import type { Metadata } from 'next';

/**
 * Generate page-specific metadata with common SEO fields
 */
export function generateMetadata({
  title,
  description,
  path,
}: {
  title: string;
  description: string;
  path: string;
}): Metadata {
  const siteUrl = 'https://appliedphysiology.com';
  const fullUrl = `${siteUrl}${path}`;

  return {
    title: `${title} | Applied Physiology & Nutrition`,
    description: description,
    keywords: [
      'applied physiology',
      'nutrition science',
      'evidence-based health',
      'human physiology',
      'metabolic health',
      'digestive health',
      'hormonal health',
      'sports nutrition',
      'scientific health education',
    ],
    authors: [{ name: 'Paromita' }],
    creator: 'Paromita',
    publisher: 'Applied Physiology & Nutrition',
    robots: 'index, follow',
    alternates: {
      canonical: fullUrl,
    },
    openGraph: {
      title: `${title} | Applied Physiology & Nutrition`,
      description: description,
      url: fullUrl,
      siteName: 'Applied Physiology & Nutrition',
      locale: 'en_US',
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title: `${title} | Applied Physiology & Nutrition`,
      description: description,
      creator: '@appliedphysiology',
      images: {
        url: '/images/hero-digestion.jpg',
        alt: title,
      },
    },
  };
}

/**
 * Get appropriate image for each section
 */
export const sectionImages: Record<string, { url: string; width: number; height: number; alt: string }> = {
  homepage: {
    url: '/images/hero-digestion.jpg',
    width: 1344,
    height: 768,
    alt: 'Applied Physiology & Nutrition - Evidence-Based Health Education',
  },
  about: {
    url: '/images/research.jpg',
    width: 1024,
    height: 1024,
    alt: 'Applied Physiology & Nutrition - About - The Empathetic Scientist',
  },
  fundamentals: {
    url: '/images/metabolism.jpg',
    width: 1024,
    height: 1024,
    alt: 'Applied Physiology & Nutrition - The Fundamentals',
  },
  nutrition: {
    url: '/images/healthy-meal.jpg',
    width: 1024,
    height: 1024,
    alt: 'Applied Physiology & Nutrition - Nutrition Science',
  },
  performance: {
    url: '/images/fitness.jpg',
    width: 1024,
    height: 1024,
    alt: 'Applied Physiology & Nutrition - Performance & Life',
  },
  therapeutic: {
    url: '/images/healthy-meal.jpg',
    width: 1024,
    height: 1024,
    alt: 'Applied Physiology & Nutrition - Therapeutic Nutrition',
  },
  articles: {
    url: '/images/hero-digestion.jpg',
    width: 1024,
    height: 1024,
    alt: 'Applied Physiology & Nutrition - Article Library',
  },
  resources: {
    url: '/images/healthy-meal.jpg',
    width: 1024,
    height: 1024,
    alt: 'Applied Physiology & Nutrition - Resources & Tools',
  },
  research: {
    url: '/images/research.jpg',
    width: 1024,
    height: 1024,
    alt: 'Applied Physiology & Nutrition - Research Radar',
  },
};
