'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from '@/components/ui/navigation-menu';
import { Menu, Brain, Activity, Dumbbell, Pill, Calculator, BookOpen, Search } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    {
      label: 'The Fundamentals',
      icon: Brain,
      href: '/fundamentals',
      subItems: [
        { label: 'Digestive Physiology', href: '/fundamentals/digestion' },
        { label: 'Metabolism', href: '/fundamentals/metabolism' },
        { label: 'Hormonal Health', href: '/fundamentals/hormones' },
        { label: 'Cardiovascular System', href: '/fundamentals/cardiovascular' },
      ],
    },
    {
      label: 'Nutrition Science',
      icon: Activity,
      href: '/nutrition',
      subItems: [
        { label: 'Macronutrients', href: '/nutrition/macronutrients' },
        { label: 'Micronutrients', href: '/nutrition/micronutrients' },
        { label: 'Hydration', href: '/nutrition/hydration' },
        { label: 'Supplements', href: '/nutrition/supplements' },
      ],
    },
    {
      label: 'Performance & Life',
      icon: Dumbbell,
      href: '/performance',
      subItems: [
        { label: 'Sports Nutrition', href: '/performance/sports' },
        { label: 'Circadian Rhythms', href: '/performance/circadian' },
        { label: 'Stress Physiology', href: '/performance/stress' },
      ],
    },
    {
      label: 'Therapeutic Nutrition',
      icon: Pill,
      href: '/therapeutic',
      subItems: [
        { label: 'PCOS Management', href: '/therapeutic/pcos' },
        { label: 'Diabetes', href: '/therapeutic/diabetes' },
        { label: 'Hypertension', href: '/therapeutic/hypertension' },
        { label: 'Gut Health', href: '/therapeutic/gut-health' },
      ],
    },
  ];

  return (
    <header
      className={cn(
        'sticky top-0 z-50 w-full transition-all duration-220',
        isScrolled
          ? 'glass border-b border-border/50'
          : 'bg-background border-b border-border'
      )}
    >
      <div className="container-custom">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2 group">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary text-primary-foreground transition-transform group-hover:scale-105">
              <Brain className="w-5 h-5" />
            </div>
            <div className="hidden sm:flex flex-col">
              <span className="font-bold text-sm leading-tight">Applied Physiology</span>
              <span className="font-medium text-xs text-muted-foreground leading-tight">& Nutrition</span>
            </div>
            <span className="sm:hidden font-bold text-sm">AP&N</span>
          </Link>

          {/* Desktop Navigation */}
          <NavigationMenu className="hidden lg:flex">
            <NavigationMenuList>
              {navItems.map((item) => (
                <NavigationMenuItem key={item.label}>
                  <NavigationMenuTrigger className="h-10 text-sm font-medium">
                    <item.icon className="w-4 h-4 mr-2" />
                    {item.label}
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[200px] gap-1 p-2">
                      {item.subItems.map((subItem) => (
                        <li key={subItem.label}>
                          <NavigationMenuLink asChild>
                            <Link
                              href={subItem.href}
                              className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                            >
                              <div className="text-sm font-medium leading-none">{subItem.label}</div>
                            </Link>
                          </NavigationMenuLink>
                        </li>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
              ))}
            </NavigationMenuList>
          </NavigationMenu>

          {/* Right Side Actions */}
          <div className="flex items-center gap-2">
            <Link href="/about">
              <Button variant="ghost" size="sm" className="hidden sm:inline-flex">
                About
              </Button>
            </Link>
            <Link href="/resources">
              <Button variant="ghost" size="sm" className="hidden sm:inline-flex">
                <Calculator className="w-4 h-4 mr-2" />
                Resources
              </Button>
            </Link>
            <Link href="/research">
              <Button variant="ghost" size="sm" className="hidden sm:inline-flex">
                <Search className="w-4 h-4 mr-2" />
                Research Radar
              </Button>
            </Link>

            {/* Mobile Menu Trigger */}
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="ghost" size="icon" className="w-9 h-9">
                  <Menu className="w-5 h-5" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[350px]">
                <nav className="flex flex-col space-y-4 mt-8">
                  <Link
                    href="/about"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="flex items-center space-x-2 text-sm font-medium"
                  >
                    <BookOpen className="w-4 h-4" />
                    <span>About</span>
                  </Link>
                  <Link
                    href="/resources"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="flex items-center space-x-2 text-sm font-medium"
                  >
                    <Calculator className="w-4 h-4" />
                    <span>Resources</span>
                  </Link>
                  <Link
                    href="/research"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="flex items-center space-x-2 text-sm font-medium"
                  >
                    <Search className="w-4 h-4" />
                    <span>Research Radar</span>
                  </Link>

                  <div className="pt-4 border-t">
                    <p className="text-xs font-semibold text-muted-foreground mb-3 px-2">
                      PILLARS OF KNOWLEDGE
                    </p>
                    {navItems.map((item) => (
                      <div key={item.label} className="space-y-2 mb-4">
                        <Link
                          href={item.href}
                          onClick={() => setIsMobileMenuOpen(false)}
                          className="flex items-center space-x-2 px-2 py-1 text-sm font-medium"
                        >
                          <item.icon className="w-4 h-4 text-primary" />
                          <span>{item.label}</span>
                        </Link>
                        <div className="pl-6 space-y-1">
                          {item.subItems.map((subItem) => (
                            <Link
                              key={subItem.label}
                              href={subItem.href}
                              onClick={() => setIsMobileMenuOpen(false)}
                              className="block py-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                            >
                              {subItem.label}
                            </Link>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
