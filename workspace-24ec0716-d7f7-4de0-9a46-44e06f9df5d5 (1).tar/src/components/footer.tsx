import Link from 'next/link';
import { Brain, Mail, BookOpen, Search } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-muted/50 border-t border-border mt-auto">
      <div className="container-custom py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-3">
            <Link href="/" className="flex items-center space-x-2 group">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary text-primary-foreground transition-transform group-hover:scale-105">
                <Brain className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-sm leading-tight">Applied Physiology</span>
                <span className="font-medium text-xs text-muted-foreground leading-tight">& Nutrition</span>
              </div>
            </Link>
            <p className="text-sm text-muted-foreground">
              Decoding Your Biology, Fueling Your Life. Evidence-based health education for the curious mind.
            </p>
          </div>

          {/* Pillars */}
          <div>
            <h3 className="font-semibold text-sm mb-4">Pillars of Knowledge</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/fundamentals" className="hover:text-foreground transition-colors">
                  The Fundamentals
                </Link>
              </li>
              <li>
                <Link href="/nutrition" className="hover:text-foreground transition-colors">
                  Nutrition Science
                </Link>
              </li>
              <li>
                <Link href="/performance" className="hover:text-foreground transition-colors">
                  Performance & Life
                </Link>
              </li>
              <li>
                <Link href="/therapeutic" className="hover:text-foreground transition-colors">
                  Therapeutic Nutrition
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="font-semibold text-sm mb-4">Resources</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/about" className="flex items-center space-x-2 hover:text-foreground transition-colors">
                  <BookOpen className="w-4 h-4" />
                  <span>About</span>
                </Link>
              </li>
              <li>
                <Link href="/resources" className="hover:text-foreground transition-colors">
                  TDEE Calculator
                </Link>
              </li>
              <li>
                <Link href="/resources/glossary" className="hover:text-foreground transition-colors">
                  Glossary
                </Link>
              </li>
              <li>
                <Link href="/resources/downloadables" className="hover:text-foreground transition-colors">
                  Downloadables
                </Link>
              </li>
              <li>
                <Link href="/research" className="flex items-center space-x-2 hover:text-foreground transition-colors">
                  <Search className="w-4 h-4" />
                  <span>Research Radar</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-sm mb-4">Connect</h3>
            <div className="space-y-3 text-sm text-muted-foreground">
              <p>Have questions or feedback?</p>
              <Link href="mailto:hello@appliedphysiology.com" className="flex items-center space-x-2 hover:text-primary transition-colors">
                <Mail className="w-4 h-4" />
                <span>Get in Touch</span>
              </Link>
            </div>
          </div>
        </div>

        <Separator className="my-8" />

        {/* Medical Disclaimer */}
        <div className="bg-background border border-border rounded-lg p-6">
          <h4 className="font-semibold text-sm mb-2 flex items-center">
            <span className="w-2 h-2 rounded-full bg-accent mr-2" />
            Medical Disclaimer
          </h4>
          <p className="text-xs text-muted-foreground leading-relaxed">
            The content provided on the "Applied Physiology & Nutrition" portal, including text, graphics, images, and other material, is for informational and educational purposes only. It is not intended to be a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified healthcare provider with any questions you may have regarding a medical condition. Never disregard professional medical advice or delay in seeking it because of something you have read on this website. Reliance on any information provided by this website is solely at your own risk.
          </p>
        </div>

        <Separator className="my-8" />

        {/* Copyright */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <p>
            © {currentYear} Applied Physiology & Nutrition. All rights reserved.
          </p>
          <div className="flex items-center space-x-4">
            <Link href="/privacy" className="hover:text-foreground transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms" className="hover:text-foreground transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
